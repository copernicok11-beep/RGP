# GUÍA DE ARTE: cómo cambiar las imágenes sin tocar código
Todo el arte vive en `app/assets/arte/`. El juego carga cada PNG por su nombre. Si cambias un archivo por otro **con el mismo nombre y el mismo tamaño**, el juego lo usa solo. Si borras uno, el juego dibuja un cuadro de color en su lugar y sigue funcionando.
Ya hay arte de relleno con los nombres y tamaños correctos: úsalo como plantilla (ábrelo en tu editor de pixel art y dibuja encima).

## Reglas generales
- **Un cuadro del mapa = 16×16 píxeles.** Todo se mide en cuadros.
- PNG con fondo transparente. Sin suavizado (pixel art puro).
- Vista desde arriba, ligeramente de frente (como Stardew Valley o Pokémon).

## Suelos y objetos: `assets/arte/tiles/`
| Archivo | Tamaño | Qué es |
|---|---|---|
| pasto.png, agua.png, agua_honda.png, agua_orilla.png, arena.png, camino.png, plaza.png, madera.png | 16×16 | Suelos que se repiten. Deben poder repetirse sin que se noten los bordes. `agua_orilla` va pegada a la costa y `agua_honda` lejos de ella |
| agua_1..4.png, agua_honda_1..4.png, agua_orilla_1..4.png | 16×16 | Animación del agua: 4 fotogramas por tipo, que el juego alterna solo (velocidad: `kFpsAgua` en `pantalla.dart`). Si faltan, usa `agua.png`, `agua_honda.png` y `agua_orilla.png` fijos |
| arbol.png | 16×24 | Árbol. Se apoya en la parte de abajo del cuadro; sobresale hacia arriba |
| farola.png | 16×24 | Farola |
| cabina.png | 16×24 | Cabina telefónica |
| banca.png, roca.png, valla.png, flores.png | 16×16 | Objetos pequeños |
| fuente.png | 32×32 | Fuente de la plaza (ocupa 2×2 cuadros) |
| sombrilla_roja.png, sombrilla_azul.png | 16×24 | Sombrillas de la playa |
| toalla_rayas.png, toalla_azul.png, conchas.png | 16×16 | Objetos planos de la playa (Aldo camina encima) |
| reposera.png, barril.png | 16×16 | Reposera y barril de la playa |
| barco.png | 48×32 | Bote varado en la orilla (ocupa 3×2 cuadros) |

## Edificios: `assets/arte/edificios/<id>.png`
Cada edificio es **una sola imagen** del tamaño de su huella: ancho × 16 por alto × 16 (ver tabla). La puerta debe quedar abajo, en la columna central. El nombre del negocio puede ir en un letrero dibujado en la fachada.

| Archivo | Cuadros (ancho×alto) | Píxeles |
|---|---|---|
| marea.png (La Marea) | 12×8 | 192×128 |
| estacion.png (Estación de rescate) | 10×6 | 160×96 |
| radio.png (Radio Don Beto) | 6×5 | 96×80 |
| tinta.png (Tinta Salada) | 6×5 | 96×80 |
| bar.png (Bar Cielo Abierto) | 9×6 | 144×96 |
| faro_dorado.png (El Faro Dorado) | 10×6 | 160×96 |
| clinica.png | 8×8 | 128×128 |
| voz.png (La Voz del Puerto) | 8×8 | 128×128 |
| hostal.png (Hostal Brisa) | 10×7 | 160×112 |
| mercado.png (Mercado de Chela) | 11×7 | 176×112 |
| vivero.png (Vivero Raíces) | 11×7 | 176×112 |
| iglesia.png | 10×7 | 160×112 |
| casa_lucas.png, casa_adrian.png, casa_valeria.png, casa_noa.png, casa_camila.png, casa_elias.png | 6×5 | 96×80 |

## Personajes: `assets/arte/personajes/`
Una hoja por personaje. **aldo.png = 48×96 píxeles**: 3 columnas × 4 filas, cada cuadro de **16×24**.
- Columnas: 1 = parado, 2 = paso con un pie, 3 = paso con el otro. (Al caminar alterna 2 y 3 pasando por el 1.)
- Filas, de arriba a abajo: **1 = mirando abajo (de frente), 2 = izquierda, 3 = derecha, 4 = arriba (de espaldas)**.
- Los pies quedan en el borde de abajo del cuadro.
Los demás personajes (Gael, Lucas, etc.) usarán el mismo formato con su propio nombre (`gael.png`, `lucas.png`...).

## Cómo probar tu arte
1. Reemplaza los PNG en `app/assets/arte/...` con los tuyos (mismo nombre, mismo tamaño).
2. Vuelve a empaquetar el proyecto y lanza el APK como siempre.
3. Para ver el pueblo y la playa juntos sin compilar: `python3 tools/vista_previa.py` genera `vista_previa_pueblo.png` y `vista_previa_playa.png` con el arte que tengas (no toca tus PNG). En cambio `python3 tools/generar_arte.py` rehace el arte de relleno y **sobrescribe** tus PNG: no lo corras si ya dibujaste los tuyos.

## Zonas del juego (mapas)
- `app/assets/mapa/pueblo.txt` + `edificios.json`: Puerto Alba, 120×110 cuadros.
- `app/assets/mapa/playa.txt` + `playa.json`: la playa, 90×50 cuadros, conectada al norte del pueblo.
- Para cambiar los mapas edita `app/tools/generar_mapa.py` y corre `python3 tools/generar_mapa.py` desde `app/`. Los edificios conservan sus ids y tamaños, así que el arte de arriba sigue valiendo.
- Cada `.json` puede tener `salidas`: rectángulos que al pisarlos llevan a otra zona (`destino` y cuadro de `llegada`).
