import 'dart:ui' as ui;
import 'package:flutter/services.dart';

/// Carga las imagenes que existan en assets/arte/ (png). Si falta una, el juego
/// usa el dibujo hecho con codigo. La clave es la ruta sin "assets/arte/" ni ".png",
/// por ejemplo "tiles/pasto", "edificios/marea" o "personajes/aldo".
class Arte {
  final Map<String, ui.Image> imagenes = {};

  ui.Image? operator [](String clave) => imagenes[clave];

  Future<void> cargar() async {
    try {
      final manifiesto = await AssetManifest.loadFromAssetBundle(rootBundle);
      for (final ruta in manifiesto.listAssets()) {
        if (!ruta.startsWith('assets/arte/') || !ruta.endsWith('.png')) continue;
        try {
          final datos = await rootBundle.load(ruta);
          final codec = await ui.instantiateImageCodec(datos.buffer.asUint8List());
          final cuadro = await codec.getNextFrame();
          imagenes[ruta.substring('assets/arte/'.length, ruta.length - 4)] = cuadro.image;
        } catch (_) {
          // una imagen danada no debe tumbar el juego
        }
      }
    } catch (_) {}
  }
}
