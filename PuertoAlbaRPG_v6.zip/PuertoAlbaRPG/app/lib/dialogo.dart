import 'dart:convert';
import 'package:flutter/services.dart';
import 'reloj.dart';

int _min(String hhmm) {
  final p = hhmm.split(':');
  return int.parse(p[0]) * 60 + int.parse(p[1]);
}

/// Una linea hablada. [quien] = 'GAEL', 'ALDO', 'NARRACION'...
class LineaDlg {
  final String quien, texto;
  LineaDlg(this.quien, this.texto);

  static List<LineaDlg> lista(dynamic j) =>
      ((j as List?) ?? const []).map((e) => LineaDlg((e as List)[0] as String, e[1] as String)).toList();
}

/// Una respuesta que Aldo puede elegir. Cambia las barras ocultas (C, K) del personaje y puede activar una marca.
class OpcionDlg {
  final String texto;
  final int c, k;
  final String? flag, accion;
  final List<LineaDlg> respuesta;
  OpcionDlg(this.texto, this.c, this.k, this.flag, this.accion, this.respuesta);
}

/// Una escena de conversacion con condiciones (zona, hora, semana, lugar).
class EscenaDlg {
  final String id;
  final List<String> zonas;
  final int desde, hasta, semanaMin, semanaMax;
  final List<int>? lugar; // x0, y0, x1, y1 donde debe estar el personaje
  final List<LineaDlg> lineas;
  final List<OpcionDlg> opciones;
  EscenaDlg(this.id, this.zonas, this.desde, this.hasta, this.semanaMin, this.semanaMax, this.lugar, this.lineas, this.opciones);

  bool cumple(String zona, double px, double py, Reloj r) {
    if (zonas.isNotEmpty && !zonas.contains(zona)) return false;
    final m = r.minutosEnteros;
    if (m < desde || m > hasta) return false;
    if (r.semana < semanaMin || r.semana > semanaMax) return false;
    final l = lugar;
    if (l != null && (px < l[0] || px >= l[2] + 1 || py < l[1] || py >= l[3] + 1)) return false;
    return true;
  }
}

/// Barras ocultas y marcas de la partida (se guardaran mas adelante).
class EstadoJuego {
  final Set<String> flags = {};
  final Set<String> vistos = {};
  final Map<String, int> afecto = {}; // 'gael.C', 'gael.K'
  int charlas = 0;

  void sumar(String pj, int c, int k) {
    if (c != 0) afecto['$pj.C'] = (afecto['$pj.C'] ?? 0) + c;
    if (k != 0) afecto['$pj.K'] = (afecto['$pj.K'] ?? 0) + k;
  }

  int valor(String pj, String barra) => afecto['$pj.$barra'] ?? 0;
}

class Dialogos {
  final Map<String, List<EscenaDlg>> escenas = {};
  final Map<String, List<LineaDlg>> charlas = {};

  static Future<Dialogos> cargar() async {
    final d = Dialogos();
    final j = jsonDecode(await rootBundle.loadString('assets/datos/dialogos.json')) as Map<String, dynamic>;
    j.forEach((pj, v) {
      final m = v as Map<String, dynamic>;
      d.escenas[pj] = (m['escenas'] as List).cast<Map<String, dynamic>>().map((e) {
        final opciones = (e['opciones'] as List? ?? const []).cast<Map<String, dynamic>>().map((o) => OpcionDlg(
              o['texto'] as String,
              (o['C'] as num?)?.toInt() ?? 0,
              (o['K'] as num?)?.toInt() ?? 0,
              o['flag'] as String?,
              o['accion'] as String?,
              LineaDlg.lista(o['respuesta']),
            )).toList();
        return EscenaDlg(
          e['id'] as String,
          ((e['zonas'] as List?) ?? const []).cast<String>(),
          e['desde'] == null ? 0 : _min(e['desde'] as String),
          e['hasta'] == null ? 24 * 60 : _min(e['hasta'] as String),
          (e['semanaMin'] as num?)?.toInt() ?? 1,
          (e['semanaMax'] as num?)?.toInt() ?? 52,
          (e['lugar'] as List?)?.cast<num>().map((n) => n.toInt()).toList(),
          LineaDlg.lista(e['lineas']),
          opciones,
        );
      }).toList();
      d.charlas[pj] = LineaDlg.lista(m['charlas']);
    });
    return d;
  }

  /// Primera escena que aun no se vio y cuyas condiciones se cumplen.
  EscenaDlg? buscar(String pj, String zona, double px, double py, Reloj r, EstadoJuego e) {
    for (final s in escenas[pj] ?? const <EscenaDlg>[]) {
      if (e.vistos.contains(s.id)) continue;
      if (s.cumple(zona, px, py, r)) return s;
    }
    return null;
  }
}
