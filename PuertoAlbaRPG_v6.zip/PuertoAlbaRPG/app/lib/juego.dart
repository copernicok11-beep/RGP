import 'dart:math';
import 'package:flutter/material.dart';
import 'arte.dart';
import 'dialogo.dart';
import 'mapa.dart';
import 'npc.dart';
import 'reloj.dart';

/// Direcciones de la cruceta.
const int kArriba = 0, kAbajo = 1, kIzquierda = 2, kDerecha = 3;

/// Estado y reglas del juego (por ahora: caminar por el pueblo y la playa, y acercarse a las puertas).
class Juego extends ChangeNotifier {
  /// Todas las zonas del juego, por nombre ('pueblo', 'playa'...).
  final Map<String, Mapa> mapas;
  final Arte arte;
  final Reloj reloj;
  final Dialogos dialogos;
  final List<Npc> npcs;
  late final Navegacion nav;
  final EstadoJuego estado = EstadoJuego();

  /// Quien habla y las respuestas a elegir (si las hay) mientras dura una conversacion.
  String? hablante;
  List<OpcionDlg>? opciones;
  List<LineaDlg> _lineas = [];
  int _li = 0;
  List<OpcionDlg>? _opcFinal;
  String _pj = '';

  /// Zona donde esta Aldo ahora.
  String zona;
  Mapa get mapa => mapas[zona]!;

  /// Posicion de los pies de Aldo, en cuadros (1.0 = un cuadro).
  double px, py;

  /// Hacia donde mira: 0 abajo, 1 izquierda, 2 derecha, 3 arriba (orden de la hoja de sprites).
  int cara = 0;
  bool moviendo = false;
  double animT = 0;
  double tiempo = 0;
  bool depuracion = false;
  String? mensaje;

  /// Oscurecimiento de la pantalla al cambiar de zona (0 = nada, 1 = negro total).
  double fundido = 0;

  /// Nombre de la zona recien visitada, se muestra unos segundos.
  String? rotuloZona;

  static const double velocidad = 4.2; // cuadros por segundo
  static const double _duracionFundido = 0.22; // segundos

  int _fase = 0; // 0 normal, 1 oscureciendo, 2 aclarando
  bool _finDia = false; // el fundido en curso es el de fin de dia
  Salida? _salida;
  double _rotuloT = 0;

  final List<bool> _tecla = [false, false, false, false];
  final Map<String, TextPainter> _rotulos = {};

  Juego(Map<String, Mapa> mapas, this.arte, this.reloj, this.dialogos, this.npcs, {String zonaInicial = 'pueblo'})
      : mapas = mapas,
        zona = zonaInicial,
        px = mapas[zonaInicial]!.inicioX + 0.5,
        py = mapas[zonaInicial]!.inicioY + 0.5 {
    nav = Navegacion(mapas);
    for (final n in npcs) {
      n.colocar(reloj);
    }
  }

  void pulsar(int direccion, bool abajo) {
    _tecla[direccion] = abajo;
  }

  void actualizar(double dt) {
    tiempo += dt;
    _actualizarFundido(dt);
    if (_rotuloT > 0) {
      _rotuloT -= dt;
      if (_rotuloT <= 0) rotuloZona = null;
    }
    var vx = 0.0, vy = 0.0;
    if (mensaje == null && _fase == 0) {
      if (_tecla[kArriba]) vy -= 1;
      if (_tecla[kAbajo]) vy += 1;
      if (_tecla[kIzquierda]) vx -= 1;
      if (_tecla[kDerecha]) vx += 1;
    }
    moviendo = vx != 0 || vy != 0;
    if (moviendo) {
      if (vx.abs() >= vy.abs() && vx != 0) {
        cara = vx < 0 ? 1 : 2;
      } else {
        cara = vy < 0 ? 3 : 0;
      }
      final largo = sqrt(vx * vx + vy * vy);
      vx = vx / largo * velocidad * dt;
      vy = vy / largo * velocidad * dt;
      _mover(vx, 0);
      _mover(0, vy);
      animT += dt;
    } else {
      animT = 0;
    }
    // el tiempo corre solo cuando Aldo esta libre (sin mensajes ni fundidos)
    if (mensaje == null && _fase == 0) {
      if (reloj.avanzar(dt)) {
        _finDia = true;
        _fase = 1;
      }
    }
    if (mensaje == null && _fase == 0 && !reloj.pausado) {
      for (final n in npcs) {
        n.actualizar(dt, nav, reloj, reloj.velocidad);
      }
    }
    if (_fase == 0) {
      final s = mapa.salidaEn(px, py);
      if (s != null && mapas.containsKey(s.destino)) {
        _salida = s;
        _fase = 1;
      }
    }
    notifyListeners();
  }

  /// Fundido a negro, cambio de zona y fundido de vuelta.
  void _actualizarFundido(double dt) {
    if (_fase == 1) {
      fundido += dt / _duracionFundido;
      if (fundido >= 1) {
        fundido = 1;
        final s = _salida;
        if (_finDia) {
          _finDia = false;
          _empezarNuevoDia();
        } else if (s != null) {
          zona = s.destino;
          px = s.llegadaX + 0.5;
          py = s.llegadaY + 0.5;
          rotuloZona = mapa.nombre.isEmpty ? null : mapa.nombre;
          _rotuloT = 2.4;
        }
        _salida = null;
        _fase = 2;
      }
    } else if (_fase == 2) {
      fundido -= dt / _duracionFundido;
      if (fundido <= 0) {
        fundido = 0;
        _fase = 0;
      }
    }
  }

  /// Medianoche: Aldo vuelve a casa (el inicio del pueblo) y amanece el dia siguiente.
  void _empezarNuevoDia() {
    reloj.nuevoDia();
    for (final n in npcs) {
      n.colocar(reloj);
    }
    zona = mapas.containsKey('marea_arriba') ? 'marea_arriba' : 'pueblo';
    px = mapa.inicioX + 0.5;
    py = mapa.inicioY + 0.5;
    cara = 0;
    rotuloZona = null;
    _mensajeSimple(textoDeDia(amanecer: true));
  }

  /// Resumen del dia: fecha, semana, estacion y festividad.
  String textoDeDia({bool amanecer = false}) {
    final b = StringBuffer();
    if (reloj.finDeJuego) {
      b.write('Ultimo dia del año.\n${reloj.fechaTexto} de 1996/97');
    } else {
      b.write('${reloj.fechaTexto}\nSemana ${reloj.semana} - ${reloj.estacion}');
    }
    final f = reloj.festividadHoy;
    if (f != null) {
      b.write('\nHoy: ${f.nombre}. ${f.descripcion}.');
    } else {
      final n = reloj.proximaFestividad;
      if (n != null && amanecer) {
        final dias = (n.semana - 1) * 7 + n.dia - ((reloj.semana - 1) * 7 + reloj.dia);
        if (dias <= 7) b.write('\nProximamente: ${n.nombre} (en $dias dias).');
      }
    }
    return b.toString();
  }

  void _mover(double dx, double dy) {
    final nx = px + dx, ny = py + dy;
    if (!_choca(nx, ny) && !_chocaNpc(nx, ny)) {
      px = nx;
      py = ny;
    }
  }

  /// Los personajes tambien estorban (pero Aldo siempre puede alejarse si ya estaba pegado).
  bool _chocaNpc(double x, double y) {
    for (final n in npcs) {
      if (n.zona != zona) continue;
      final antes = (px - n.x).abs() + (py - n.y).abs();
      final ahora = (x - n.x).abs() + (y - n.y).abs();
      if ((x - n.x).abs() < 0.55 && (y - n.y).abs() < 0.45 && ahora < antes) return true;
    }
    return false;
  }

  /// Caja de colision de los pies de Aldo.
  bool _choca(double x, double y) {
    for (final cx in [x - 0.28, x + 0.28]) {
      for (final cy in [y - 0.2, y + 0.25]) {
        if (mapa.solido(cx.floor(), cy.floor())) return true;
      }
    }
    return false;
  }

  /// Edificio cuya puerta esta justo enfrente de Aldo (si hay).
  Edificio? puertaCercana() {
    for (final e in mapa.edificios) {
      final dx = px - (e.puertaX + 0.5);
      final dy = py - (e.puertaY + 0.5);
      if (dx.abs() < 0.9 && dy > 0.2 && dy < 1.9) return e;
    }
    return null;
  }

  // ---------- mensajes y conversaciones ----------

  static String _nombreBonito(String q) => q.isEmpty ? q : q[0].toUpperCase() + q.substring(1).toLowerCase();

  void _mensajeSimple(String texto) {
    _lineas = [];
    _li = 0;
    _opcFinal = null;
    hablante = null;
    opciones = null;
    mensaje = texto;
  }

  void _cerrar() {
    _lineas = [];
    _li = 0;
    _opcFinal = null;
    hablante = null;
    opciones = null;
    mensaje = null;
  }

  void _decir(List<LineaDlg> lineas, {List<OpcionDlg>? opc}) {
    if (lineas.isEmpty) {
      _cerrar();
      return;
    }
    _lineas = lineas;
    _li = 0;
    _opcFinal = opc;
    _mostrar();
  }

  void _mostrar() {
    final l = _lineas[_li];
    hablante = l.quien == 'NARRACION' ? null : _nombreBonito(l.quien);
    mensaje = l.texto;
    opciones = _li == _lineas.length - 1 ? _opcFinal : null;
  }

  /// Aldo elige una respuesta (boton en pantalla).
  void elegir(int k) {
    final o = opciones;
    if (o == null || k < 0 || k >= o.length) return;
    final op = o[k];
    estado.sumar(_pj, op.c, op.k);
    if (op.flag != null) estado.flags.add(op.flag!);
    if (op.accion == 'dormir') {
      _cerrar();
      _finDia = true;
      _fase = 1;
    } else if (op.respuesta.isNotEmpty) {
      _decir(op.respuesta);
    } else {
      _cerrar();
    }
    notifyListeners();
  }

  /// Personaje que esta justo enfrente de Aldo (si hay).
  Npc? npcCerca() {
    final f = _frente();
    for (final n in npcs) {
      if (n.zona != zona) continue;
      final dx = n.x - px, dy = n.y - py;
      if (dx * dx + dy * dy < 1.5 * 1.5 && dx * f[0] + dy * f[1] > -0.1) return n;
    }
    return null;
  }

  List<double> _frente() {
    switch (cara) {
      case 1:
        return [-1, 0];
      case 2:
        return [1, 0];
      case 3:
        return [0, -1];
      default:
        return [0, 1];
    }
  }

  /// Texto o punto especial del objeto que Aldo tiene enfrente (solo en interiores).
  Punto? _objetoEnfrente() {
    if (!mapa.interior) return null;
    final f = _frente();
    final tx = (px + f[0] * 0.75).floor(), ty = (py + f[1] * 0.75).floor();
    final p = mapa.puntoEn(tx, ty);
    if (p != null) return p;
    final t = mapa.textos[mapa.en(tx, ty)];
    if (t == null || !mapa.solido(tx, ty)) return null;
    return Punto(tx, ty, t, null);
  }

  bool get hayObjetoEnfrente => mensaje == null && _objetoEnfrente() != null;

  void _hablarCon(Npc n) {
    n.mirarA(px, py);
    _pj = n.id;
    final esc = dialogos.buscar(n.id, zona, n.x, n.y, reloj, estado);
    if (esc != null) {
      estado.vistos.add(esc.id);
      _decir(esc.lineas, opc: esc.opciones.isEmpty ? null : esc.opciones);
    } else {
      final l = dialogos.charlas[n.id] ?? const <LineaDlg>[];
      if (l.isEmpty) return;
      _decir([l[estado.charlas++ % l.length]]);
    }
  }

  void _preguntarDormir() {
    if (reloj.minutosEnteros < 18 * 60) {
      _mensajeSimple('Todavia no tienes sueno. (Puedes dormir despues de las 18:00.)');
      return;
    }
    _pj = 'aldo';
    _decir([LineaDlg('NARRACION', 'Tu cama. Mañana sera otro dia en Puerto Alba. Dormir ahora?')], opc: [
      OpcionDlg('Dormir hasta manana', 0, 0, null, 'dormir', []),
      OpcionDlg('Todavia no', 0, 0, null, null, []),
    ]);
  }

  void _entrar(Edificio e) {
    final dentro = mapas[e.id]!;
    _salida = Salida(0, 0, 0, 0, e.id, dentro.inicioX, dentro.inicioY);
    _fase = 1;
  }

  /// Boton A: avanzar el texto, hablar, entrar a un edificio o examinar un objeto.
  void accion() {
    if (_fase != 0) return;
    if (mensaje != null) {
      if (opciones != null) return; // hay que elegir una respuesta
      if (_lineas.isNotEmpty && _li < _lineas.length - 1) {
        _li++;
        _mostrar();
      } else {
        _cerrar();
      }
      notifyListeners();
      return;
    }
    final n = npcCerca();
    if (n != null) {
      _hablarCon(n);
      notifyListeners();
      return;
    }
    final e = puertaCercana();
    if (e != null) {
      if (e.id != 'marea' && !reloj.estaAbierto(e.id)) {
        _mensajeSimple('${e.nombre}\nEsta cerrado. ${reloj.proximaApertura(e.id)}');
      } else if (mapas.containsKey(e.id)) {
        _entrar(e);
      } else {
        _mensajeSimple('${e.nombre}\nEl interior se agregara pronto.');
      }
      notifyListeners();
      return;
    }
    final o = _objetoEnfrente();
    if (o != null) {
      if (o.accion == 'dormir') {
        _preguntarDormir();
      } else if (o.texto != null) {
        _mensajeSimple(o.texto!);
      }
      notifyListeners();
    }
  }

  /// Toca el reloj: cambia la velocidad del tiempo (pausa, x1, x2, x4).
  void ciclarVelocidad() {
    reloj.ciclarVelocidad();
    notifyListeners();
  }

  /// Muestra el resumen del dia actual.
  void verFecha() {
    if (mensaje == null && _fase == 0) {
      _mensajeSimple(textoDeDia());
      notifyListeners();
    }
  }

  void alternarDepuracion() {
    depuracion = !depuracion;
    notifyListeners();
  }

  /// Rotulo de texto en cache (para los letreros de los edificios).
  TextPainter rotulo(String texto) {
    return _rotulos.putIfAbsent(texto, () {
      final tp = TextPainter(
        text: TextSpan(
          text: texto,
          style: const TextStyle(color: Color(0xFFFFF3D6), fontSize: 0.36, fontWeight: FontWeight.bold, height: 1.0),
        ),
        textDirection: TextDirection.ltr,
      );
      tp.layout();
      return tp;
    });
  }
}
