import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'arte.dart';
import 'dialogo.dart';
import 'juego.dart';
import 'mapa.dart';
import 'npc.dart';
import 'pantalla.dart';
import 'reloj.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  runApp(const PuertoAlbaRpg());
}

class PuertoAlbaRpg extends StatelessWidget {
  const PuertoAlbaRpg({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Puerto Alba',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(brightness: Brightness.dark, useMaterial3: true),
      home: const Arranque(),
    );
  }
}

/// Carga las zonas (pueblo y playa) y las imagenes, y luego abre el juego.
class Arranque extends StatefulWidget {
  const Arranque({super.key});

  @override
  State<Arranque> createState() => _ArranqueState();
}

class _ArranqueState extends State<Arranque> {
  Juego? _juego;
  String? _error;

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  Future<void> _cargar() async {
    try {
      final pueblo = await Mapa.cargar('pueblo.txt', 'edificios.json');
      final playa = await Mapa.cargar('playa.txt', 'playa.json');
      final marea = await Mapa.cargar('marea.txt', 'marea.json');
      final arriba = await Mapa.cargar('marea_arriba.txt', 'marea_arriba.json');
      final arte = Arte();
      await arte.cargar();
      final reloj = await Reloj.cargar();
      final dialogos = await Dialogos.cargar();
      final npcs = await Npc.cargar();
      setState(() => _juego = Juego({'pueblo': pueblo, 'playa': playa, 'marea': marea, 'marea_arriba': arriba}, arte, reloj, dialogos, npcs));
    } catch (e) {
      setState(() => _error = '$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) {
      return Scaffold(body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Text('No se pudo cargar el pueblo:\n$_error'))));
    }
    if (_juego == null) {
      return const Scaffold(backgroundColor: Colors.black, body: Center(child: Text('Puerto Alba, 1996...', style: TextStyle(fontSize: 20))));
    }
    return PantallaJuego(juego: _juego!);
  }
}
