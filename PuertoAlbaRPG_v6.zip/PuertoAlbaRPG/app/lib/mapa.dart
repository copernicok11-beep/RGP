import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Un edificio del pueblo (se dibuja con codigo o con una imagen en assets/arte/edificios/<id>.png).
class Edificio {
  final String id;
  final String nombre;
  final int x, y, w, h;
  final Color techo, pared;
  final int puertaX, puertaY;
  Edificio(this.id, this.nombre, this.x, this.y, this.w, this.h, this.techo, this.pared, this.puertaX, this.puertaY);

  factory Edificio.desdeJson(Map<String, dynamic> j) {
    final p = (j['puerta'] as List).cast<num>();
    return Edificio(
      j['id'] as String,
      j['nombre'] as String,
      (j['x'] as num).toInt(),
      (j['y'] as num).toInt(),
      (j['w'] as num).toInt(),
      (j['h'] as num).toInt(),
      Mapa.hex(j['techo'] as String),
      Mapa.hex(j['pared'] as String),
      p[0].toInt(),
      p[1].toInt(),
    );
  }
}

/// Una salida: al pisar este rectangulo (en cuadros) Aldo pasa a otra zona del juego.
class Salida {
  final int x, y, w, h;
  final String destino;
  final int llegadaX, llegadaY;
  Salida(this.x, this.y, this.w, this.h, this.destino, this.llegadaX, this.llegadaY);

  factory Salida.desdeJson(Map<String, dynamic> j) {
    final l = (j['llegada'] as List).cast<num>();
    return Salida(
      (j['x'] as num).toInt(),
      (j['y'] as num).toInt(),
      (j['w'] as num).toInt(),
      (j['h'] as num).toInt(),
      j['destino'] as String,
      l[0].toInt(),
      l[1].toInt(),
    );
  }

  bool contiene(double px, double py) => px >= x && px < x + w && py >= y && py < y + h;
}

/// Un punto especial de un interior (cama para dormir, un objeto con texto propio...).
class Punto {
  final int x, y;
  final String? texto;
  final String? accion;
  Punto(this.x, this.y, this.texto, this.accion);
}

/// Una zona del juego (el pueblo, la playa...): una cuadricula de caracteres (assets/mapa/<zona>.txt),
/// mas su lista de edificios y de salidas (en el .json de la zona).
class Mapa {
  final String nombre;
  final int ancho, alto;
  final List<String> filas;
  final List<Edificio> edificios;
  final List<Salida> salidas;
  final int inicioX, inicioY;

  /// Los interiores (casas, tiendas) se dibujan distinto y no tienen luz de dia.
  final bool interior;

  /// Texto al examinar un objeto de interior (por caracter) y puntos especiales (por coordenada).
  final Map<String, String> textos;
  final List<Punto> puntos;

  /// Caracteres por los que no se puede caminar.
  static const String solidos = '~aeTFLbCrvWDSZHKB';

  /// Lo mismo en un interior: paredes y muebles.
  static const String solidosInterior = '#EBMFRCDOTPN';

  /// Caracteres que son suelo de verdad. Los demas (arboles, farolas, edificios...) son objetos
  /// y toman el suelo de los cuadros vecinos.
  static const String _chSuelo = '.~aes=pm';

  Mapa(this.nombre, this.ancho, this.alto, this.filas, this.edificios, this.salidas, this.inicioX, this.inicioY,
      {this.interior = false, this.textos = const {}, this.puntos = const []});

  late final List<String> _suelos = _calcularSuelos();

  static Color hex(String h) => Color(0xFF000000 | int.parse(h.substring(1), radix: 16));

  /// Carga una zona: [archivoTxt] y [archivoJson] estan dentro de assets/mapa/.
  static Future<Mapa> cargar(String archivoTxt, String archivoJson) async {
    final texto = await rootBundle.loadString('assets/mapa/$archivoTxt');
    final filas = texto.split('\n').where((l) => l.trim().isNotEmpty).map((l) => l.trimRight()).toList();
    final j = jsonDecode(await rootBundle.loadString('assets/mapa/$archivoJson')) as Map<String, dynamic>;
    final edificios = ((j['edificios'] as List?) ?? const <dynamic>[])
        .map((e) => Edificio.desdeJson(e as Map<String, dynamic>))
        .toList();
    final salidas = ((j['salidas'] as List?) ?? const <dynamic>[])
        .map((s) => Salida.desdeJson(s as Map<String, dynamic>))
        .toList();
    final ini = (j['inicio'] as List).cast<num>();
    final textos = ((j['textos'] as Map?) ?? const {}).map((k, v) => MapEntry(k as String, v as String));
    final puntos = ((j['puntos'] as List?) ?? const <dynamic>[]).map((e) {
      final m = e as Map<String, dynamic>;
      return Punto((m['x'] as num).toInt(), (m['y'] as num).toInt(), m['texto'] as String?, m['accion'] as String?);
    }).toList();
    return Mapa(
      (j['nombre'] as String?) ?? '',
      (j['ancho'] as num).toInt(),
      (j['alto'] as num).toInt(),
      filas,
      edificios,
      salidas,
      ini[0].toInt(),
      ini[1].toInt(),
      interior: j['interior'] == true,
      textos: textos,
      puntos: puntos,
    );
  }

  String en(int x, int y) {
    if (x < 0 || y < 0 || y >= filas.length) return interior ? '#' : '~';
    final f = filas[y];
    if (x >= f.length) return interior ? '#' : '~';
    return f[x];
  }

  bool solido(int x, int y) => (interior ? solidosInterior : solidos).contains(en(x, y));

  /// Punto especial en (x, y), si hay.
  Punto? puntoEn(int x, int y) {
    for (final p in puntos) {
      if (p.x == x && p.y == y) return p;
    }
    return null;
  }

  /// Suelo que hay debajo del cuadro (x, y): el propio cuadro si es suelo, o el de sus vecinos si es un objeto.
  String suelo(int x, int y) {
    if (x < 0 || y < 0 || y >= alto || x >= ancho) return '~';
    return _suelos[y][x];
  }

  /// Salida que Aldo esta pisando (si hay), segun la posicion de sus pies.
  Salida? salidaEn(double px, double py) {
    for (final s in salidas) {
      if (s.contiene(px, py)) return s;
    }
    return null;
  }

  List<String> _calcularSuelos() {
    final g = List.generate(alto, (y) => List.generate(ancho, (x) => en(x, y)));
    final ok = List.generate(alto, (y) => List.generate(ancho, (x) => _chSuelo.contains(g[y][x])));
    const vecinos = [
      [0, 1],
      [1, 0],
      [-1, 0],
      [0, -1],
    ];
    for (var vuelta = 0; vuelta < 8; vuelta++) {
      final cambios = <List<Object>>[];
      for (var y = 0; y < alto; y++) {
        for (var x = 0; x < ancho; x++) {
          if (ok[y][x]) continue;
          for (final d in vecinos) {
            final nx = x + d[0], ny = y + d[1];
            if (nx < 0 || ny < 0 || ny >= alto || nx >= ancho || !ok[ny][nx]) continue;
            cambios.add([x, y, g[ny][nx]]);
            break;
          }
        }
      }
      if (cambios.isEmpty) break;
      for (final c in cambios) {
        g[c[1] as int][c[0] as int] = c[2] as String;
        ok[c[1] as int][c[0] as int] = true;
      }
    }
    return [
      for (var y = 0; y < alto; y++) [for (var x = 0; x < ancho; x++) ok[y][x] ? g[y][x] : '.'].join(),
    ];
  }
}
