import 'dart:collection';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/services.dart';
import 'mapa.dart';
import 'reloj.dart';

int _min(String hhmm) {
  final p = hhmm.split(':');
  return int.parse(p[0]) * 60 + int.parse(p[1]);
}

/// Un lugar donde debe estar un personaje desde cierta hora.
class EntradaAgenda {
  final List<int> dias;
  final int desde;
  final String zona;
  final int x, y, cara;
  final String nota;
  EntradaAgenda(this.dias, this.desde, this.zona, this.x, this.y, this.cara, this.nota);
}

/// Paso de una zona a otra: caminar hasta (sx, sy) y aparecer en (ax, ay) de la zona [destino].
class Enlace {
  final String destino;
  final int sx, sy, ax, ay;
  Enlace(this.destino, this.sx, this.sy, this.ax, this.ay);
}

/// Mapa de conexiones entre zonas y busqueda de caminos (para que los personajes caminen solos).
class Navegacion {
  final Map<String, Mapa> mapas;
  final Map<String, List<Enlace>> enlaces = {};

  Navegacion(this.mapas) {
    mapas.forEach((zona, m) {
      final lista = enlaces.putIfAbsent(zona, () => []);
      for (final s in m.salidas) {
        if (!mapas.containsKey(s.destino)) continue;
        lista.add(Enlace(s.destino, s.x + s.w ~/ 2, s.y + s.h ~/ 2, s.llegadaX, s.llegadaY));
      }
      for (final e in m.edificios) {
        final dentro = mapas[e.id];
        if (dentro == null) continue; // el edificio no tiene interior todavia
        lista.add(Enlace(e.id, e.puertaX, e.puertaY + 1, dentro.inicioX, dentro.inicioY));
      }
    });
  }

  /// Lista de enlaces a seguir para ir de la zona [a] a la zona [b] (vacia si ya esta; null si no hay camino).
  List<Enlace>? rutaZonas(String a, String b) {
    if (a == b) return [];
    final previo = <String, Enlace>{};
    final origen = <String, String>{};
    final cola = Queue<String>()..add(a);
    final vistos = <String>{a};
    while (cola.isNotEmpty) {
      final z = cola.removeFirst();
      for (final e in enlaces[z] ?? const <Enlace>[]) {
        if (!vistos.add(e.destino)) continue;
        previo[e.destino] = e;
        origen[e.destino] = z;
        if (e.destino == b) {
          final ruta = <Enlace>[];
          var c = b;
          while (c != a) {
            ruta.insert(0, previo[c]!);
            c = origen[c]!;
          }
          return ruta;
        }
        cola.add(e.destino);
      }
    }
    return null;
  }

  /// Camino de cuadros (sin incluir el de salida) de (sx, sy) a (tx, ty) dentro de una zona. Null si no hay.
  List<List<int>>? camino(Mapa m, int sx, int sy, int tx, int ty) {
    if (sx == tx && sy == ty) return [];
    final w = m.ancho, h = m.alto;
    bool dentro(int x, int y) => x >= 0 && y >= 0 && x < w && y < h;
    if (!dentro(tx, ty)) return null;
    final previo = List<int>.filled(w * h, -2);
    final cola = Queue<int>()..add(sy * w + sx);
    previo[sy * w + sx] = -1;
    const d = [
      [1, 0],
      [-1, 0],
      [0, 1],
      [0, -1],
    ];
    while (cola.isNotEmpty) {
      final c = cola.removeFirst();
      final cx = c % w, cy = c ~/ w;
      if (cx == tx && cy == ty) {
        final ruta = <List<int>>[];
        var k = c;
        while (previo[k] != -1) {
          ruta.insert(0, [k % w, k ~/ w]);
          k = previo[k];
        }
        return ruta;
      }
      for (final v in d) {
        final nx = cx + v[0], ny = cy + v[1];
        if (!dentro(nx, ny) || previo[ny * w + nx] != -2 || m.solido(nx, ny)) continue;
        previo[ny * w + nx] = c;
        cola.add(ny * w + nx);
      }
    }
    return null;
  }
}

/// Un personaje que camina por el mundo siguiendo su agenda.
class Npc {
  final String id, nombre, sprite;
  final double velocidad;
  final List<EntradaAgenda> agenda;

  String zona;
  double x = 0, y = 0;
  int cara = 0; // 0 abajo, 1 izquierda, 2 derecha, 3 arriba
  bool moviendo = false;
  double animT = 0;

  EntradaAgenda? _objetivo;
  List<List<int>> _ruta = [];
  Enlace? _enlace;

  Npc(this.id, this.nombre, this.sprite, this.velocidad, this.agenda, this.zona);

  static Future<List<Npc>> cargar() async {
    final j = jsonDecode(await rootBundle.loadString('assets/datos/horarios_npc.json')) as Map<String, dynamic>;
    final lista = <Npc>[];
    j.forEach((id, v) {
      final m = v as Map<String, dynamic>;
      final agenda = (m['agenda'] as List).cast<Map<String, dynamic>>().map((e) => EntradaAgenda(
            (e['dias'] as List).cast<int>(),
            _min(e['desde'] as String),
            e['zona'] as String,
            (e['x'] as num).toInt(),
            (e['y'] as num).toInt(),
            (e['cara'] as num?)?.toInt() ?? 0,
            (e['nota'] as String?) ?? '',
          )).toList();
      lista.add(Npc(id, m['nombre'] as String, (m['sprite'] as String?) ?? id, (m['velocidad'] as num?)?.toDouble() ?? 2.4, agenda, agenda.first.zona));
    });
    return lista;
  }

  /// A donde le toca estar ahora segun el dia y la hora.
  EntradaAgenda? agendaActual(Reloj r) {
    EntradaAgenda? mejor;
    EntradaAgenda? primera;
    for (final e in agenda) {
      if (!e.dias.contains(r.dia)) continue;
      if (primera == null || e.desde < primera.desde) primera = e;
      if (e.desde <= r.minutosEnteros && (mejor == null || e.desde > mejor.desde)) mejor = e;
    }
    return mejor ?? primera;
  }

  /// Lo coloca de golpe donde le toca estar (al empezar el dia).
  void colocar(Reloj r) {
    final o = agendaActual(r);
    if (o == null) return;
    zona = o.zona;
    x = o.x + 0.5;
    y = o.y + 0.5;
    cara = o.cara;
    _objetivo = o;
    _ruta = [];
    _enlace = null;
    moviendo = false;
  }

  /// Se voltea hacia un punto (cuando Aldo le habla).
  void mirarA(double ax, double ay) {
    final dx = ax - x, dy = ay - y;
    if (dx.abs() >= dy.abs()) {
      cara = dx < 0 ? 1 : 2;
    } else {
      cara = dy < 0 ? 3 : 0;
    }
  }

  void _planear(Navegacion nav) {
    final o = _objetivo;
    if (o == null) return;
    final mapa = nav.mapas[zona];
    if (mapa == null) return;
    final sx = x.floor(), sy = y.floor();
    if (o.zona == zona) {
      _enlace = null;
      final c = nav.camino(mapa, sx, sy, o.x, o.y);
      if (c == null) {
        x = o.x + 0.5; // sin camino: aparece en su sitio
        y = o.y + 0.5;
        _ruta = [];
      } else {
        _ruta = c;
      }
      return;
    }
    final ruta = nav.rutaZonas(zona, o.zona);
    if (ruta == null || ruta.isEmpty) {
      colocar2(o);
      return;
    }
    final e = ruta.first;
    final c = nav.camino(mapa, sx, sy, e.sx, e.sy);
    if (c == null) {
      colocar2(o);
      return;
    }
    _enlace = e;
    _ruta = c;
  }

  void colocar2(EntradaAgenda o) {
    zona = o.zona;
    x = o.x + 0.5;
    y = o.y + 0.5;
    _ruta = [];
    _enlace = null;
  }

  /// Avanza [dt] segundos; [mult] = velocidad del reloj (x1, x2, x4).
  void actualizar(double dt, Navegacion nav, Reloj r, int mult) {
    final o = agendaActual(r);
    if (o != null && !identical(o, _objetivo)) {
      _objetivo = o;
      _planear(nav);
    }
    var resto = velocidad * dt * max(1, mult);
    moviendo = false;
    var giros = 0;
    while (resto > 0 && giros < 8) {
      if (_ruta.isNotEmpty) {
        final t = _ruta.first;
        final tx = t[0] + 0.5, ty = t[1] + 0.5;
        final dx = tx - x, dy = ty - y;
        final dist = sqrt(dx * dx + dy * dy);
        if (dist <= resto) {
          x = tx;
          y = ty;
          resto -= dist;
          _ruta.removeAt(0);
        } else {
          x += dx / dist * resto;
          y += dy / dist * resto;
          resto = 0;
        }
        if (dist > 0.001) {
          if (dx.abs() >= dy.abs()) {
            cara = dx < 0 ? 1 : 2;
          } else {
            cara = dy < 0 ? 3 : 0;
          }
        }
        moviendo = true;
      } else if (_enlace != null) {
        final e = _enlace!;
        zona = e.destino;
        x = e.ax + 0.5;
        y = e.ay + 0.5;
        _enlace = null;
        _planear(nav);
        giros++;
      } else {
        if (_objetivo != null && !moviendo) cara = _objetivo!.cara;
        break;
      }
    }
    if (moviendo) {
      animT += dt;
    } else {
      animT = 0;
    }
  }
}
