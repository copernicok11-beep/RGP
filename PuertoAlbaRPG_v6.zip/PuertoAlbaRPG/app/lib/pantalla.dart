import 'dart:math' as math;
import 'dart:ui' show FontFeature;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'arte.dart';
import 'juego.dart';
import 'mapa.dart';

/// Cuantos cuadros de ancho se ven a la vez en la pantalla.
const double kCuadrosAncho = 26;

/// Tamano (en pixeles del arte) de un cuadro, y del personaje.
const double kPx = 16;

/// Fotogramas por segundo de la animacion del agua (agua_1..4.png en assets/arte/tiles/).
const double kFpsAgua = 2.5;
const double kPersonajeAlto = 24;

double _lim(double v, double a, double b) => v < a ? a : (v > b ? b : v);

class PantallaJuego extends StatefulWidget {
  final Juego juego;
  const PantallaJuego({super.key, required this.juego});

  @override
  State<PantallaJuego> createState() => _PantallaJuegoState();
}

class _PantallaJuegoState extends State<PantallaJuego> with SingleTickerProviderStateMixin {
  late final Ticker _ticker;
  Duration _ultimo = Duration.zero;

  @override
  void initState() {
    super.initState();
    _ticker = createTicker((t) {
      final dt = math.min(0.05, (t - _ultimo).inMicroseconds / 1000000.0);
      _ultimo = t;
      widget.juego.actualizar(dt);
    });
    _ticker.start();
  }

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }

  Widget _flecha(int dir, IconData icono) {
    final j = widget.juego;
    return Listener(
      behavior: HitTestBehavior.opaque,
      onPointerDown: (_) => j.pulsar(dir, true),
      onPointerUp: (_) => j.pulsar(dir, false),
      onPointerCancel: (_) => j.pulsar(dir, false),
      child: Container(
        width: 62,
        height: 62,
        decoration: BoxDecoration(
          color: const Color(0x88000000),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0x66FFFFFF), width: 2),
        ),
        child: Icon(icono, color: Colors.white70, size: 38),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final j = widget.juego;
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          Positioned.fill(
            child: CustomPaint(painter: PintorPueblo(j)),
          ),
          // cruceta
          Positioned(
            left: 22,
            bottom: 18,
            child: SizedBox(
              width: 190,
              height: 190,
              child: Stack(
                children: [
                  Positioned(left: 64, top: 0, child: _flecha(kArriba, Icons.keyboard_arrow_up)),
                  Positioned(left: 64, bottom: 0, child: _flecha(kAbajo, Icons.keyboard_arrow_down)),
                  Positioned(left: 0, top: 64, child: _flecha(kIzquierda, Icons.keyboard_arrow_left)),
                  Positioned(right: 0, top: 64, child: _flecha(kDerecha, Icons.keyboard_arrow_right)),
                ],
              ),
            ),
          ),
          // boton de accion
          Positioned(
            right: 34,
            bottom: 40,
            child: Listener(
              behavior: HitTestBehavior.opaque,
              onPointerDown: (_) => j.accion(),
              child: Container(
                width: 86,
                height: 86,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: const Color(0x99C0562B),
                  shape: BoxShape.circle,
                  border: Border.all(color: const Color(0xAAFFFFFF), width: 3),
                ),
                child: const Text('A', style: TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.bold)),
              ),
            ),
          ),
          // reloj y fecha (esquina superior izquierda): tocar la hora cambia la velocidad, tocar la fecha muestra el dia
          Positioned(
            left: 8,
            top: 8,
            child: AnimatedBuilder(
              animation: j,
              builder: (context, _) {
                final r = j.reloj;
                final vel = r.pausado ? 'II' : 'x${r.velocidad}';
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: const Color(0xAA1B2A38),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: const Color(0x88E8DCC0), width: 1.5),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: j.verFecha,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(r.fechaTexto, style: const TextStyle(color: Color(0xFFFFF3D6), fontSize: 13, fontWeight: FontWeight.bold)),
                            Text('Semana ${r.semana}/52 - ${r.estacion}', style: const TextStyle(color: Color(0xFFE8DCC0), fontSize: 11)),
                          ],
                        ),
                      ),
                      const SizedBox(width: 10),
                      GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: j.ciclarVelocidad,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(r.horaTexto, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold, fontFeatures: [FontFeature.tabularFigures()])),
                            Text(vel, style: const TextStyle(color: Color(0xFFF0B060), fontSize: 11, fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          // depuracion (esquina superior derecha)
          Positioned(
            right: 8,
            top: 8,
            child: GestureDetector(
              onTap: j.alternarDepuracion,
              child: const Padding(
                padding: EdgeInsets.all(8),
                child: Icon(Icons.grid_on, color: Colors.white38, size: 22),
              ),
            ),
          ),
          // aviso "A: entrar" y cuadro de mensaje
          AnimatedBuilder(
            animation: j,
            builder: (context, _) {
              final libre = j.mensaje == null;
              final cerca = libre ? j.puertaCercana() : null;
              final npc = libre ? j.npcCerca() : null;
              final objeto = libre && npc == null && cerca == null && j.hayObjetoEnfrente;
              return Stack(
                children: [
                  if (npc != null || objeto)
                    Positioned(
                      top: 14,
                      left: 0,
                      right: 0,
                      child: Center(
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                          decoration: BoxDecoration(color: const Color(0xCC000000), borderRadius: BorderRadius.circular(8)),
                          child: Text(npc != null ? 'A: hablar con ${npc.nombre}' : 'A: examinar', style: const TextStyle(color: Colors.white, fontSize: 15)),
                        ),
                      ),
                    ),
                  if (cerca != null && npc == null)
                    Positioned(
                      top: 14,
                      left: 0,
                      right: 0,
                      child: Center(
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                          decoration: BoxDecoration(color: const Color(0xCC000000), borderRadius: BorderRadius.circular(8)),
                          child: Text(cerca.id == 'marea' || j.reloj.estaAbierto(cerca.id) ? 'A: entrar a ${cerca.nombre}' : '${cerca.nombre} (cerrado)', style: const TextStyle(color: Colors.white, fontSize: 15)),
                        ),
                      ),
                    ),
                  if (j.rotuloZona != null)
                    Positioned(
                      top: 64,
                      left: 0,
                      right: 0,
                      child: Center(
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                          decoration: BoxDecoration(
                            color: const Color(0xCC1B2A38),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: const Color(0xFFE8DCC0), width: 2),
                          ),
                          child: Text(j.rotuloZona!, style: const TextStyle(color: Color(0xFFFFF3D6), fontSize: 18, fontWeight: FontWeight.bold)),
                        ),
                      ),
                    ),
                  if (j.opciones != null)
                    Positioned(
                      left: 120,
                      right: 150,
                      bottom: 150,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          for (var i = 0; i < j.opciones!.length; i++)
                            Padding(
                              padding: const EdgeInsets.only(top: 6),
                              child: GestureDetector(
                                behavior: HitTestBehavior.opaque,
                                onTap: () => j.elegir(i),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                                  decoration: BoxDecoration(
                                    color: const Color(0xF0C0562B),
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(color: const Color(0xFFFFF3D6), width: 1.5),
                                  ),
                                  child: Text(j.opciones![i].texto, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  if (j.mensaje != null)
                    Positioned(
                      left: 120,
                      right: 150,
                      bottom: 16,
                      child: GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: j.accion,
                        child: Stack(
                          clipBehavior: Clip.none,
                          children: [
                            Container(
                              width: double.infinity,
                              padding: EdgeInsets.fromLTRB(14, j.hablante != null ? 20 : 14, 14, 14),
                              decoration: BoxDecoration(
                                color: const Color(0xEE1B2A38),
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(color: const Color(0xFFE8DCC0), width: 2),
                              ),
                              child: Text(j.mensaje!, style: const TextStyle(color: Color(0xFFFFF3D6), fontSize: 17, height: 1.3)),
                            ),
                            if (j.hablante != null)
                              Positioned(
                                left: 12,
                                top: -14,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFC0562B),
                                    borderRadius: BorderRadius.circular(6),
                                    border: Border.all(color: const Color(0xFFFFF3D6), width: 1.5),
                                  ),
                                  child: Text(j.hablante!, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}

/// Dibuja el pueblo, los objetos, los edificios y a Aldo. Usa las imagenes de assets/arte/
/// cuando existen y, si falta alguna, un dibujo de color hecho con codigo.
class PintorPueblo extends CustomPainter {
  final Juego j;
  PintorPueblo(this.j) : super(repaint: j);

  Mapa get mapa => j.mapa;
  Arte get arte => j.arte;

  static const Map<String, String> _suelo = {
    '.': 'pasto', '~': 'agua', 'a': 'agua_honda', 'e': 'agua_orilla', 's': 'arena', '=': 'camino', 'p': 'plaza', 'm': 'madera',
  };
  static const Map<String, List<String>> _fotosAgua = {
    'agua': ['agua_1', 'agua_2', 'agua_3', 'agua_4'],
    'agua_honda': ['agua_honda_1', 'agua_honda_2', 'agua_honda_3', 'agua_honda_4'],
    'agua_orilla': ['agua_orilla_1', 'agua_orilla_2', 'agua_orilla_3', 'agua_orilla_4'],
  };
  static const Map<String, String> _objeto = {
    'T': 'arbol', 'L': 'farola', 'F': 'fuente', 'b': 'banca', 'C': 'cabina', 'f': 'flores', 'r': 'roca', 'v': 'valla',
    'S': 'sombrilla_roja', 'Z': 'sombrilla_azul', 'H': 'reposera', 'K': 'barril', 'B': 'barco',
  };
  // Objetos planos: se dibujan pegados al suelo (Aldo camina encima de ellos)
  static const Map<String, String> _plano = {'o': 'toalla_rayas', 'q': 'toalla_azul', 'h': 'conchas'};
  static const Map<String, Color> _colorPlano = {'o': Color(0xFFD63E38), 'q': Color(0xFF5AAADC), 'h': Color(0xFFFAE2D6)};
  static const Map<String, Color> _color = {
    'pasto': Color(0xFF5E9B49), 'agua': Color(0xFF3E7CB1), 'agua_honda': Color(0xFF2F6FA3), 'agua_orilla': Color(0xFF69AEC9), 'arena': Color(0xFFE3CE93), 'camino': Color(0xFFB08A58),
    'plaza': Color(0xFFAFA89B), 'madera': Color(0xFF8A5E34),
  };

  void _imagen(Canvas c, String clave, Rect destino, Paint p, {Rect? origen}) {
    final img = arte[clave];
    if (img == null) return;
    final src = origen ?? Rect.fromLTWH(0, 0, img.width.toDouble(), img.height.toDouble());
    c.drawImageRect(img, src, destino, p);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final cuadro = size.width / kCuadrosAncho;
    final visW = kCuadrosAncho;
    final visH = size.height / cuadro;
    final camX = _lim(j.px - visW / 2, 0, math.max(0.0, mapa.ancho - visW));
    final camY = _lim(j.py - visH / 2, 0, math.max(0.0, mapa.alto - visH));
    if (mapa.interior) {
      _pintarInterior(canvas, size);
      return;
    }

    canvas.save();
    canvas.scale(cuadro);
    canvas.translate(-camX, -camY);
    final p = Paint()
      ..filterQuality = FilterQuality.none
      ..isAntiAlias = false;

    final x0 = camX.floor(), x1 = (camX + visW).ceil();
    final y0 = camY.floor(), y1 = (camY + visH).ceil();

    // 1) suelo
    for (var y = y0; y < y1; y++) {
      for (var x = x0; x < x1; x++) {
        var clave = _suelo[mapa.suelo(x, y)] ?? 'pasto';
        final fotos = _fotosAgua[clave];
        if (fotos != null) {
          // agua animada: cada zona del mar va en un fotograma distinto, asi las olas parecen avanzar
          final f = fotos[((j.tiempo * kFpsAgua).floor() + (x ~/ 3) + (y ~/ 2)) % fotos.length];
          if (arte['tiles/$f'] != null) clave = f;
        }
        final dest = Rect.fromLTWH(x.toDouble(), y.toDouble(), 1.02, 1.02);
        if (arte['tiles/$clave'] != null) {
          _imagen(canvas, 'tiles/$clave', dest, p);
        } else {
          canvas.drawRect(dest, Paint()..color = _color[clave] ?? const Color(0xFF5E9B49));
        }
      }
    }

    // 1b) objetos planos (toallas, conchas)
    for (var y = y0; y < y1; y++) {
      for (var x = x0; x < x1; x++) {
        final ch = mapa.en(x, y);
        final clave = _plano[ch];
        if (clave == null) continue;
        if (arte['tiles/$clave'] != null) {
          _imagen(canvas, 'tiles/$clave', Rect.fromLTWH(x.toDouble(), y.toDouble(), 1.0, 1.0), p);
        } else {
          canvas.drawRect(Rect.fromLTWH(x + 0.15, y + 0.2, 0.7, 0.6), Paint()..color = _colorPlano[ch]!);
        }
      }
    }

    // 2) objetos, edificios y Aldo, ordenados por la "base" para que se tapen bien
    final cosas = <MapEntry<double, void Function()>>[];

    for (var y = math.max(0, y0 - 2); y < math.min(mapa.alto, y1 + 2); y++) {
      for (var x = x0 - 2; x < x1 + 2; x++) {
        final ch = mapa.en(x, y);
        final clave = _objeto[ch];
        if (clave == null) continue;
        final grande = ch == 'F' || ch == 'B';   // fuente (2x2) y barco (3x2): se dibujan desde su esquina
        if (grande && (mapa.en(x - 1, y) == ch || mapa.en(x, y - 1) == ch)) continue;
        final img = arte['tiles/$clave'];
        if (img != null) {
          final w = img.width / kPx, h = img.height / kPx;
          if (grande) {
            cosas.add(MapEntry(y + h, () => _imagen(canvas, 'tiles/$clave', Rect.fromLTWH(x.toDouble(), y.toDouble(), w, h), p)));
          } else {
            cosas.add(MapEntry(y + 1.0, () => _imagen(canvas, 'tiles/$clave', Rect.fromLTWH(x.toDouble(), y + 1 - h, w, h), p)));
          }
        } else {
          cosas.add(MapEntry(y + 1.0, () {
            final col = Paint()..color = ch == 'T' ? const Color(0xFF2F6B2F) : const Color(0xFF555555);
            canvas.drawRect(Rect.fromLTWH(x + 0.1, y + 0.1, 0.8, 0.8), col);
          }));
        }
      }
    }

    for (final e in mapa.edificios) {
      if (e.x > x1 || e.x + e.w < x0 || e.y > y1 || e.y + e.h < y0) continue;
      cosas.add(MapEntry(e.y + e.h.toDouble(), () {
        final dest = Rect.fromLTWH(e.x.toDouble(), e.y.toDouble(), e.w.toDouble(), e.h.toDouble());
        if (arte['edificios/${e.id}'] != null) {
          _imagen(canvas, 'edificios/${e.id}', dest, p);
        } else {
          canvas.drawRect(dest, Paint()..color = e.pared);
          canvas.drawRect(Rect.fromLTWH(dest.left, dest.top, dest.width, dest.height * 0.55), Paint()..color = e.techo);
        }
      }));
    }

    for (final n in j.npcs) {
      if (n.zona != j.zona) continue;
      cosas.add(MapEntry(n.y + 0.25, () => _pintarPersonaje(canvas, p, n.sprite, n.x, n.y, n.cara, n.moviendo, n.animT, const Color(0xFFD66A3A))));
    }
    cosas.add(MapEntry(j.py + 0.25, () => _pintarAldo(canvas, p)));
    cosas.sort((a, b) => a.key.compareTo(b.key));
    for (final c in cosas) {
      c.value();
    }

    if (j.depuracion) _depuracion(canvas, x0, y0, x1, y1);
    canvas.restore();

    // luz del dia: tinte segun la hora (solo al aire libre; los interiores no existen aun)
    final tinte = _tinteHora(j.reloj.minutos);
    if (tinte.alpha > 0) canvas.drawRect(Offset.zero & size, Paint()..color = tinte);

    // fundido a negro al cambiar de zona
    if (j.fundido > 0) {
      final alfa = (255 * _lim(j.fundido, 0, 1)).round();
      canvas.drawRect(Offset.zero & size, Paint()..color = Color.fromARGB(alfa, 0, 0, 0));
    }
  }

  static const List<List<num>> _luz = [
    // minuto, A, R, G, B
    [0, 150, 10, 16, 48],
    [5 * 60, 140, 14, 20, 56],
    [6 * 60, 90, 70, 60, 110],
    [7 * 60, 50, 255, 150, 90],
    [8 * 60 + 30, 0, 255, 220, 170],
    [16 * 60, 0, 255, 230, 180],
    [17 * 60 + 30, 40, 255, 170, 90],
    [19 * 60, 85, 230, 100, 90],
    [20 * 60, 120, 60, 50, 110],
    [21 * 60 + 30, 150, 10, 16, 48],
    [24 * 60, 150, 10, 16, 48],
  ];

  Color _tinteHora(double m) {
    for (var i = 0; i < _luz.length - 1; i++) {
      final a = _luz[i], b = _luz[i + 1];
      if (m >= a[0] && m <= b[0]) {
        final t = (m - a[0]) / (b[0] - a[0]);
        int mezcla(int k) => (a[k] + (b[k] - a[k]) * t).round();
        return Color.fromARGB(mezcla(1), mezcla(2), mezcla(3), mezcla(4));
      }
    }
    return const Color(0x00000000);
  }

  void _pintarAldo(Canvas canvas, Paint p) {
    _pintarPersonaje(canvas, p, 'aldo', j.px, j.py, j.cara, j.moviendo, j.animT, const Color(0xFF3F6C9B));
  }

  void _pintarPersonaje(Canvas canvas, Paint p, String sprite, double x, double y, int cara, bool moviendo, double animT, Color respaldo) {
    // sombra
    canvas.drawOval(Rect.fromCenter(center: Offset(x, y + 0.22), width: 0.7, height: 0.26), Paint()..color = const Color(0x44000000));
    final img = arte['personajes/$sprite'];
    if (img == null) {
      canvas.drawRect(Rect.fromLTWH(x - 0.3, y - 1.0, 0.6, 1.25), Paint()..color = respaldo);
      return;
    }
    const ciclo = [0, 1, 0, 2];
    final frame = moviendo ? ciclo[(animT * 8).floor() % 4] : 0;
    final src = Rect.fromLTWH(frame * kPx, cara * kPersonajeAlto, kPx, kPersonajeAlto);
    final dest = Rect.fromLTWH(x - 0.5, y + 0.25 - kPersonajeAlto / kPx, 1.0, kPersonajeAlto / kPx);
    canvas.drawImageRect(img, src, dest, p);
  }

  void _fundidoNegro(Canvas canvas, Size size) {
    if (j.fundido > 0) {
      final alfa = (255 * _lim(j.fundido, 0, 1)).round();
      canvas.drawRect(Offset.zero & size, Paint()..color = Color.fromARGB(alfa, 0, 0, 0));
    }
  }

  // ---------- interiores ----------

  static const String _muebles = 'EBMFRCDOTPN';

  void _rc(Canvas c, double l, double t, double w, double h, int col) {
    c.drawRect(Rect.fromLTWH(l, t, w, h), Paint()..color = Color(col));
  }

  void _pintarInterior(Canvas canvas, Size size) {
    final cuadro = size.width / mapa.ancho;
    final visH = size.height / cuadro;
    final camY = mapa.alto <= visH ? (mapa.alto - visH) / 2 : _lim(j.py - visH / 2, 0, mapa.alto - visH.toDouble());
    canvas.drawRect(Offset.zero & size, Paint()..color = const Color(0xFF14110F));
    canvas.save();
    canvas.scale(cuadro);
    canvas.translate(0, -camY);
    final p = Paint()
      ..filterQuality = FilterQuality.none
      ..isAntiAlias = false;
    for (var y = 0; y < mapa.alto; y++) {
      for (var x = 0; x < mapa.ancho; x++) {
        _pisoInterior(canvas, x, y);
      }
    }
    final cosas = <MapEntry<double, void Function()>>[];
    for (var y = 0; y < mapa.alto; y++) {
      for (var x = 0; x < mapa.ancho; x++) {
        final ch = mapa.en(x, y);
        if (_muebles.contains(ch)) cosas.add(MapEntry(y + 1.0, () => _mueble(canvas, ch, x, y)));
      }
    }
    for (final n in j.npcs) {
      if (n.zona != j.zona) continue;
      cosas.add(MapEntry(n.y + 0.25, () => _pintarPersonaje(canvas, p, n.sprite, n.x, n.y, n.cara, n.moviendo, n.animT, const Color(0xFFD66A3A))));
    }
    cosas.add(MapEntry(j.py + 0.25, () => _pintarAldo(canvas, p)));
    cosas.sort((a, b) => a.key.compareTo(b.key));
    for (final c in cosas) {
      c.value();
    }
    if (j.depuracion) _depuracion(canvas, 0, 0, mapa.ancho, mapa.alto);
    canvas.restore();
    _fundidoNegro(canvas, size);
  }

  void _pisoInterior(Canvas c, int x, int y) {
    final ch = mapa.en(x, y);
    final fx = x.toDouble(), fy = y.toDouble();
    if (ch == '#') {
      final cara = mapa.en(x, y + 1) != '#';
      _rc(c, fx, fy, 1.02, 1.02, cara ? 0xFF9A7B5C : 0xFF4A3A2E);
      if (cara) {
        _rc(c, fx, fy, 1.02, 0.08, 0xFFB69470);
        _rc(c, fx, fy + 0.82, 1.02, 0.2, 0xFF5A4332);
      }
      return;
    }
    if (ch == ',') {
      _rc(c, fx, fy, 1.02, 1.02, (x + y) % 2 == 0 ? 0xFFD8D2C0 : 0xFFC4BDA8);
      return;
    }
    // madera
    _rc(c, fx, fy, 1.02, 1.02, 0xFFB98A5C);
    _rc(c, fx, fy + 0.48, 1.02, 0.04, 0x22000000);
    _rc(c, fx + (y % 2 == 0 ? 0.3 : 0.7), fy, 0.03, 0.48, 0x18000000);
    _rc(c, fx + (y % 2 == 0 ? 0.7 : 0.3), fy + 0.52, 0.03, 0.48, 0x18000000);
    if (ch == 'm') {
      _rc(c, fx + 0.05, fy + 0.1, 0.9, 0.8, 0xFF9B3B30);
      _rc(c, fx + 0.12, fy + 0.18, 0.76, 0.64, 0xFFB5493C);
    } else if (ch == 'a') {
      _rc(c, fx, fy, 1.02, 1.02, 0xFFE0C98A);
      _rc(c, fx + 0.07, fy + 0.07, 0.88, 0.88, 0xFF3F6C7A);
    } else if (ch == 'U') {
      for (var k = 0; k < 4; k++) {
        _rc(c, fx, fy + k * 0.25, 1.02, 0.25, k.isEven ? 0xFF8A6238 : 0xFF6E4A28);
        _rc(c, fx, fy + k * 0.25 + 0.2, 1.02, 0.05, 0xFF4A3018);
      }
    }
  }

  void _mueble(Canvas c, String ch, int x, int y) {
    final fx = x.toDouble(), fy = y.toDouble();
    switch (ch) {
      case 'E': // estante con libros
        _rc(c, fx, fy - 0.4, 1, 1.4, 0xFF5E3E24);
        for (var k = 0; k < 3; k++) {
          final ty = fy - 0.3 + k * 0.42;
          _rc(c, fx + 0.06, ty, 0.88, 0.34, 0xFF3C2814);
          for (var b = 0; b < 4; b++) {
            _rc(c, fx + 0.1 + b * 0.21, ty + 0.03 + (b % 2) * 0.04, 0.16, 0.28, [0xFFB8483C, 0xFF3F6C9B, 0xFFD6A23C, 0xFF4E7E52][(b + k + x) % 4]);
          }
        }
        break;
      case 'B': // barra / mostrador
        _rc(c, fx, fy + 0.15, 1, 0.85, 0xFF6A4528);
        _rc(c, fx, fy + 0.05, 1, 0.3, 0xFFA67C52);
        _rc(c, fx, fy + 0.33, 1, 0.04, 0xFF4A3018);
        break;
      case 'M': // mesa
        _rc(c, fx + 0.1, fy + 0.25, 0.8, 0.5, 0xFFA67C52);
        _rc(c, fx + 0.1, fy + 0.7, 0.8, 0.07, 0xFF6A4528);
        _rc(c, fx + 0.15, fy + 0.75, 0.1, 0.22, 0xFF6A4528);
        _rc(c, fx + 0.75, fy + 0.75, 0.1, 0.22, 0xFF6A4528);
        _rc(c, fx + 0.4, fy + 0.3, 0.2, 0.16, 0xFFF1EBDD);
        break;
      case 'F': // estufa / cafetera
        _rc(c, fx + 0.05, fy - 0.05, 0.9, 1.05, 0xFF8A8F96);
        _rc(c, fx + 0.12, fy + 0.05, 0.76, 0.3, 0xFF3A3D42);
        _rc(c, fx + 0.2, fy + 0.12, 0.18, 0.16, 0xFFD6582B);
        _rc(c, fx + 0.6, fy + 0.12, 0.18, 0.16, 0xFFD6582B);
        _rc(c, fx + 0.15, fy + 0.5, 0.7, 0.4, 0xFF6C7078);
        break;
      case 'R': // refri
        _rc(c, fx + 0.05, fy - 0.55, 0.9, 1.55, 0xFFE6EBEF);
        _rc(c, fx + 0.05, fy + 0.15, 0.9, 0.04, 0xFF9AA4AC);
        _rc(c, fx + 0.75, fy - 0.2, 0.06, 0.25, 0xFF7A848C);
        _rc(c, fx + 0.75, fy + 0.3, 0.06, 0.3, 0xFF7A848C);
        break;
      case 'C': // cama (dos cuadros: arriba lleva la almohada)
        final arriba = mapa.en(x, y - 1) != 'C';
        _rc(c, fx + 0.05, fy, 0.9, 1, 0xFF4E6E96);
        _rc(c, fx + 0.05, fy, 0.9, 0.06, 0xFF3A5478);
        if (arriba) {
          _rc(c, fx, fy - 0.05, 1, 0.12, 0xFF6A4528);
          _rc(c, fx + 0.15, fy + 0.1, 0.7, 0.28, 0xFFF1EBDD);
        }
        break;
      case 'D': // escritorio
        _rc(c, fx, fy + 0.15, 1, 0.8, 0xFF7A5232);
        _rc(c, fx, fy + 0.15, 1, 0.3, 0xFF9A6E44);
        _rc(c, fx + 0.2, fy + 0.2, 0.3, 0.2, 0xFFF1EBDD);
        _rc(c, fx + 0.65, fy + 0.2, 0.15, 0.18, 0xFF3C3C46);
        break;
      case 'O': // sofa
        _rc(c, fx, fy + 0.1, 1, 0.9, 0xFF8C3F4A);
        _rc(c, fx, fy + 0.1, 1, 0.3, 0xFF6E2F3A);
        _rc(c, fx + 0.06, fy + 0.45, 0.88, 0.45, 0xFFA9525E);
        break;
      case 'T': // tele
        _rc(c, fx + 0.05, fy + 0.15, 0.9, 0.8, 0xFF30343A);
        _rc(c, fx + 0.12, fy + 0.22, 0.76, 0.5, 0xFF9FB8C0);
        _rc(c, fx + 0.3, fy + 0.85, 0.4, 0.1, 0xFF22262A);
        break;
      case 'P': // planta
        _rc(c, fx + 0.28, fy + 0.6, 0.44, 0.4, 0xFF9B5B3A);
        c.drawCircle(Offset(fx + 0.5, fy + 0.4), 0.3, Paint()..color = const Color(0xFF3F7E48));
        c.drawCircle(Offset(fx + 0.35, fy + 0.5), 0.2, Paint()..color = const Color(0xFF58A05C));
        c.drawCircle(Offset(fx + 0.66, fy + 0.5), 0.2, Paint()..color = const Color(0xFF58A05C));
        break;
      case 'N': // lampara de Ramon
        c.drawCircle(Offset(fx + 0.5, fy + 0.45), 0.7, Paint()..color = const Color(0x22F0C060));
        _rc(c, fx + 0.3, fy + 0.7, 0.4, 0.25, 0xFFA67C52);
        _rc(c, fx + 0.38, fy + 0.35, 0.24, 0.38, 0xFFC2903C);
        _rc(c, fx + 0.42, fy + 0.42, 0.16, 0.2, 0xFFF3D98A);
        break;
    }
  }

  void _depuracion(Canvas canvas, int x0, int y0, int x1, int y1) {
    final linea = Paint()
      ..color = const Color(0x33FFFFFF)
      ..strokeWidth = 0.02;
    for (var x = x0; x <= x1; x++) {
      canvas.drawLine(Offset(x.toDouble(), y0.toDouble()), Offset(x.toDouble(), y1.toDouble()), linea);
    }
    for (var y = y0; y <= y1; y++) {
      canvas.drawLine(Offset(x0.toDouble(), y.toDouble()), Offset(x1.toDouble(), y.toDouble()), linea);
    }
    for (var y = y0; y < y1; y++) {
      for (var x = x0; x < x1; x++) {
        if (mapa.solido(x, y)) {
          canvas.drawRect(Rect.fromLTWH(x.toDouble(), y.toDouble(), 1, 1), Paint()..color = const Color(0x33FF0000));
        }
      }
    }
    canvas.drawRect(
      Rect.fromLTRB(j.px - 0.28, j.py - 0.2, j.px + 0.28, j.py + 0.25),
      Paint()
        ..color = const Color(0xFF00FF00)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.03,
    );
  }

  @override
  bool shouldRepaint(covariant PintorPueblo old) => true;
}
