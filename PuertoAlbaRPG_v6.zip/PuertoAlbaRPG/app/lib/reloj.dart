import 'dart:convert';
import 'package:flutter/services.dart';

const List<String> kDiasNombre = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
const List<String> kMesesNombre = [
  'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'
];

/// Una festividad del calendario publico.
class Festividad {
  final int semana, dia, duracion;
  final String nombre, descripcion;
  Festividad(this.semana, this.dia, this.duracion, this.nombre, this.descripcion);

  bool cae(int s, int d) {
    final i = (s - 1) * 7 + d;
    final ini = (semana - 1) * 7 + dia;
    return i >= ini && i < ini + duracion;
  }
}

/// Franja de apertura de un negocio (minutos desde medianoche).
class _Franja {
  final List<int> dias;
  final int abre, cierra;
  _Franja(this.dias, this.abre, this.cierra);
}

int _aMinutos(String hhmm) {
  final p = hhmm.split(':');
  return int.parse(p[0]) * 60 + int.parse(p[1]);
}

String formatoHora(int minutos) {
  final h = (minutos ~/ 60) % 24, m = minutos % 60;
  return '${h.toString().padLeft(2, '0')}:${m.toString().padLeft(2, '0')}';
}

/// Reloj y calendario del juego: 52 semanas, del lunes 4 de marzo de 1996 al domingo 2 de marzo de 1997.
class Reloj {
  static const int minInicio = 6 * 60; // el dia empieza a las 06:00
  static const int minFin = 24 * 60; // y termina a medianoche
  /// Segundos reales por minuto del juego en velocidad normal (~12.6 min reales por dia).
  static const double segPorMinuto = 0.7;
  static const List<int> velocidades = [0, 1, 2, 4];

  int semana = 1; // 1..52
  int dia = 0; // 0 lunes .. 6 domingo
  double minutos = 8 * 60.0 + 30; // el primer dia empieza a las 08:30
  int idxVelocidad = 1;
  bool finDeJuego = false;

  final List<Festividad> festividades = [];
  final Map<String, List<_Franja>> _horarios = {};
  final Map<int, String> _enfoque = {};

  int get hora => minutos.floor() ~/ 60;
  int get minuto => minutos.floor() % 60;
  int get minutosEnteros => minutos.floor();
  int get velocidad => velocidades[idxVelocidad];
  bool get pausado => velocidad == 0;

  static Future<Reloj> cargar() async {
    final r = Reloj();
    final cal = jsonDecode(await rootBundle.loadString('assets/datos/calendario.json')) as Map<String, dynamic>;
    for (final f in (cal['festividades'] as List).cast<Map<String, dynamic>>()) {
      r.festividades.add(Festividad(f['semana'] as int, f['dia'] as int, f['duracion'] as int, f['nombre'] as String, f['descripcion'] as String));
    }
    for (final s in (cal['semanas'] as List).cast<Map<String, dynamic>>()) {
      r._enfoque[s['semana'] as int] = s['enfoque'] as String;
    }
    final hor = jsonDecode(await rootBundle.loadString('assets/datos/horarios_negocios.json')) as Map<String, dynamic>;
    hor.forEach((id, lista) {
      r._horarios[id] = (lista as List)
          .cast<Map<String, dynamic>>()
          .map((f) => _Franja((f['dias'] as List).cast<int>(), _aMinutos(f['abre'] as String), _aMinutos(f['cierra'] as String)))
          .toList();
    });
    return r;
  }

  // ---------- fecha ----------

  DateTime get fecha => DateTime(1996, 3, 4).add(Duration(days: (semana - 1) * 7 + dia));

  String get fechaTexto => '${kDiasNombre[dia]} ${fecha.day} de ${kMesesNombre[fecha.month - 1]}';

  String get horaTexto => formatoHora(minutosEnteros);

  String get estacion {
    if (semana <= 13) return 'Primavera';
    if (semana <= 26) return 'Verano';
    if (semana <= 39) return 'Otoño';
    return 'Invierno';
  }

  String? get enfoqueSemana => _enfoque[semana];

  /// Festividad de hoy (o null).
  Festividad? get festividadHoy {
    for (final f in festividades) {
      if (f.cae(semana, dia)) return f;
    }
    return null;
  }

  /// Proxima festividad desde hoy (sin contar las de hoy).
  Festividad? get proximaFestividad {
    final hoy = (semana - 1) * 7 + dia;
    Festividad? mejor;
    for (final f in festividades) {
      final ini = (f.semana - 1) * 7 + f.dia;
      if (ini > hoy && (mejor == null || ini < (mejor.semana - 1) * 7 + mejor.dia)) mejor = f;
    }
    return mejor;
  }

  // ---------- avance ----------

  /// Avanza el tiempo. Devuelve true si acaba de terminar el dia (medianoche).
  bool avanzar(double dt) {
    if (finDeJuego || pausado) return false;
    minutos += dt * velocidad / segPorMinuto;
    if (minutos >= minFin) {
      return true;
    }
    return false;
  }

  /// Pasa al dia siguiente a las 06:00.
  void nuevoDia() {
    dia++;
    if (dia > 6) {
      dia = 0;
      semana++;
    }
    if (semana > 52) {
      semana = 52;
      dia = 6;
      finDeJuego = true;
    }
    minutos = minInicio.toDouble();
  }

  void ciclarVelocidad() {
    idxVelocidad = (idxVelocidad + 1) % velocidades.length;
  }

  /// Avanza el reloj a una hora (usado, por ejemplo, para dormir o esperar).
  void irAHora(int h) {
    if (minutos < h * 60) minutos = h * 60.0;
  }

  // ---------- negocios ----------

  /// Esta abierto el negocio ahora? Si no tiene horario registrado, siempre esta abierto.
  bool estaAbierto(String id) {
    final f = _horarios[id];
    if (f == null) return true;
    final m = minutosEnteros;
    for (final x in f) {
      if (x.dias.contains(dia) && m >= x.abre && m < x.cierra) return true;
    }
    return false;
  }

  /// Texto para la puerta cerrada: cuando vuelve a abrir.
  String proximaApertura(String id) {
    final f = _horarios[id];
    if (f == null) return '';
    final m = minutosEnteros;
    // hoy, mas tarde
    int? hoy;
    for (final x in f) {
      if (x.dias.contains(dia) && x.abre > m && (hoy == null || x.abre < hoy)) hoy = x.abre;
    }
    if (hoy != null) return 'Abre hoy a las ${formatoHora(hoy)}.';
    for (var k = 1; k <= 7; k++) {
      final d = (dia + k) % 7;
      int? mejor;
      for (final x in f) {
        if (x.dias.contains(d) && (mejor == null || x.abre < mejor)) mejor = x.abre;
      }
      if (mejor != null) return k == 1 ? 'Abre mañana a las ${formatoHora(mejor)}.' : 'Abre el ${kDiasNombre[d].toLowerCase()} a las ${formatoHora(mejor)}.';
    }
    return '';
  }
}
