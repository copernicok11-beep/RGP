#!/usr/bin/env python3
"""Genera el ARTE DE RELLENO de Puerto Alba (PNG pixel art) en assets/arte/.
Sirve de plantilla: cada archivo ya tiene el nombre y el tamano correctos. Para usar tu arte,
reemplaza el PNG con el mismo nombre y el mismo tamano (ver GUIA_ARTE.md). No hace falta tocar codigo.
Uso (desde la carpeta app/):  python3 tools/generar_arte.py
"""
import json, os, random
from PIL import Image, ImageDraw, ImageFont

T = 16
OUT = 'assets/arte'
for d in ('tiles', 'edificios', 'personajes'):
    os.makedirs(f'{OUT}/{d}', exist_ok=True)

def img(w, h, color=(0, 0, 0, 0)):
    return Image.new('RGBA', (w, h), color)

def salpicar(im, base, tonos, n, seed):
    r = random.Random(seed)
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, im.width - 1, im.height - 1], fill=base)
    for _ in range(n):
        x, y = r.randrange(im.width), r.randrange(im.height)
        d.point((x, y), fill=r.choice(tonos))

# ---------------- suelos 16x16
def t_pasto():
    im = img(T, T); salpicar(im, (94, 155, 73, 255), [(78, 138, 60, 255), (110, 172, 88, 255)], 26, 1)
    d = ImageDraw.Draw(im)
    for (x, y) in [(3, 4), (11, 9), (6, 13)]:
        d.line([(x, y), (x, y - 2)], fill=(70, 125, 55, 255))
    return im

def t_agua():
    im = img(T, T); salpicar(im, (62, 124, 177, 255), [(56, 114, 166, 255)], 10, 2)
    d = ImageDraw.Draw(im)
    for (x, y) in [(2, 4), (9, 10)]:
        d.line([(x, y), (x + 4, y)], fill=(150, 200, 235, 255))
    return im

def t_agua_honda():
    im = img(T, T); salpicar(im, (47, 111, 163, 255), [(41, 100, 150, 255)], 10, 12)
    return im

def t_agua_orilla():
    im = img(T, T); salpicar(im, (105, 174, 201, 255), [(140, 205, 225, 255)], 14, 13)
    return im

def t_arena():
    im = img(T, T); salpicar(im, (227, 206, 147, 255), [(214, 190, 128, 255), (238, 222, 170, 255)], 30, 3)
    return im

def t_camino():
    im = img(T, T); salpicar(im, (176, 138, 88, 255), [(158, 122, 76, 255), (192, 156, 104, 255)], 34, 4)
    return im

def t_plaza():
    im = img(T, T, (175, 168, 155, 255)); d = ImageDraw.Draw(im)
    for y in (0, 8):
        d.line([(0, y), (15, y)], fill=(140, 134, 122, 255))
    for (x, y0) in ((5, 0), (11, 8), (2, 8)):
        d.line([(x, y0), (x, y0 + 7)], fill=(140, 134, 122, 255))
    return im

def t_madera():
    im = img(T, T, (138, 94, 52, 255)); d = ImageDraw.Draw(im)
    for y in (0, 5, 10, 15):
        d.line([(0, y), (15, y)], fill=(100, 66, 34, 255))
    for (x, y) in ((4, 2), (11, 7), (6, 12)):
        d.point((x, y), fill=(168, 120, 70, 255))
    return im

# ---------------- objetos (se apoyan en la parte de abajo del cuadro)
def t_arbol():
    im = img(T, 24); d = ImageDraw.Draw(im)
    d.rectangle([6, 15, 9, 22], fill=(110, 76, 44, 255))
    d.ellipse([1, 1, 14, 16], fill=(47, 107, 47, 255)); d.ellipse([3, 3, 9, 8], fill=(72, 140, 66, 255))
    d.ellipse([0, 0, 15, 17], outline=(30, 78, 34, 255))
    return im

def t_farola():
    im = img(T, 24); d = ImageDraw.Draw(im)
    d.rectangle([7, 6, 8, 22], fill=(58, 58, 66, 255)); d.rectangle([5, 2, 10, 7], fill=(255, 226, 140, 255), outline=(58, 58, 66, 255))
    d.rectangle([5, 21, 10, 23], fill=(58, 58, 66, 255))
    return im

def t_banca():
    im = img(T, T); d = ImageDraw.Draw(im)
    d.rectangle([1, 6, 14, 9], fill=(140, 96, 54, 255)); d.rectangle([1, 10, 14, 12], fill=(110, 76, 44, 255))
    d.rectangle([2, 12, 3, 15], fill=(70, 70, 76, 255)); d.rectangle([12, 12, 13, 15], fill=(70, 70, 76, 255))
    return im

def t_cabina():
    im = img(T, 24); d = ImageDraw.Draw(im)
    d.rectangle([3, 1, 12, 22], fill=(178, 40, 40, 255), outline=(110, 24, 24, 255))
    d.rectangle([5, 4, 10, 15], fill=(170, 210, 230, 255)); d.line([(7, 4), (7, 15)], fill=(110, 24, 24, 255))
    return im

def t_flores():
    im = img(T, T); r = random.Random(7); d = ImageDraw.Draw(im)
    for _ in range(6):
        x, y = r.randrange(2, 14), r.randrange(4, 14)
        d.point((x, y), fill=r.choice([(240, 120, 150, 255), (250, 220, 90, 255), (240, 240, 250, 255)]))
        d.point((x, y + 1), fill=(60, 120, 50, 255))
    return im

def t_roca():
    im = img(T, T); d = ImageDraw.Draw(im)
    d.ellipse([2, 6, 14, 15], fill=(126, 126, 134, 255), outline=(80, 80, 90, 255)); d.point((6, 9), fill=(170, 170, 178, 255))
    return im

def t_valla():
    im = img(T, T); d = ImageDraw.Draw(im)
    for x in (2, 7, 12):
        d.rectangle([x, 4, x + 1, 14], fill=(150, 106, 62, 255))
    d.line([(0, 7), (15, 7)], fill=(120, 84, 48, 255)); d.line([(0, 11), (15, 11)], fill=(120, 84, 48, 255))
    return im

def t_fuente():  # 2x2 cuadros
    im = img(32, 32, (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.ellipse([1, 3, 30, 30], fill=(150, 145, 135, 255), outline=(110, 104, 94, 255))
    d.ellipse([4, 6, 27, 27], fill=(86, 150, 200, 255), outline=(60, 110, 160, 255))
    d.rectangle([14, 8, 17, 20], fill=(150, 145, 135, 255)); d.line([(15, 4), (15, 9)], fill=(190, 225, 245, 255))
    return im

TILES = dict(pasto=t_pasto, agua=t_agua, agua_honda=t_agua_honda, agua_orilla=t_agua_orilla, arena=t_arena, camino=t_camino, plaza=t_plaza, madera=t_madera, arbol=t_arbol,
             farola=t_farola, banca=t_banca, cabina=t_cabina, flores=t_flores, roca=t_roca, valla=t_valla, fuente=t_fuente)
for nombre, f in TILES.items():
    f().save(f'{OUT}/tiles/{nombre}.png')

# ---------------- edificios (w*16 x h*16)
def hexa(h):
    return tuple(int(h[i:i + 2], 16) for i in (1, 3, 5)) + (255,)

def oscuro(c, k):
    return tuple(max(0, int(v * k)) for v in c[:3]) + (255,)

def fuente(tam):
    for ruta in ('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', '/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf'):
        if os.path.exists(ruta):
            return ImageFont.truetype(ruta, tam)
    try:
        return ImageFont.load_default(tam)
    except TypeError:
        return ImageFont.load_default()

def edificio(e):
    W, H = e['w'] * T, e['h'] * T
    im = img(W, H); d = ImageDraw.Draw(im)
    techo, pared = hexa(e['techo']), hexa(e['pared'])
    alt_techo = max(T * 2, int(H * 0.52))
    # techo
    d.rectangle([0, 0, W - 1, alt_techo], fill=techo)
    for y in range(4, alt_techo, 6):
        d.line([(0, y), (W - 1, y)], fill=oscuro(techo, 0.82))
    d.rectangle([0, alt_techo - 3, W - 1, alt_techo], fill=oscuro(techo, 0.7))
    # pared
    d.rectangle([0, alt_techo + 1, W - 1, H - 1], fill=pared, outline=oscuro(pared, 0.6))
    # ventanas
    ventana_y = alt_techo + 6
    for x in range(10, W - 14, 26):
        if abs((x + 6) - (W // 2)) < 14:
            continue
        d.rectangle([x, ventana_y, x + 11, ventana_y + 11], fill=(170, 210, 230, 255), outline=oscuro(pared, 0.5))
        d.line([(x + 6, ventana_y), (x + 6, ventana_y + 11)], fill=oscuro(pared, 0.5))
    # puerta: en la columna central, apoyada abajo
    dx = (e['puerta'][0] - e['x']) * T
    d.rectangle([dx + 2, H - 22, dx + 13, H - 1], fill=(104, 66, 38, 255), outline=(60, 38, 22, 255))
    d.point((dx + 11, H - 11), fill=(240, 200, 90, 255))
    # letrero
    f = fuente(9)
    texto = e['nombre']
    ancho = d.textlength(texto, font=f)
    if ancho > W - 8:
        f = fuente(7); ancho = d.textlength(texto, font=f)
    d.rectangle([W // 2 - ancho / 2 - 3, 4, W // 2 + ancho / 2 + 3, 16], fill=(40, 28, 20, 255))
    d.text((W // 2 - ancho / 2, 5), texto, font=f, fill=(255, 243, 214, 255))
    return im

datos = json.load(open('assets/mapa/edificios.json', encoding='utf-8'))
for e in datos['edificios']:
    edificio(e).save(f"{OUT}/edificios/{e['id']}.png")

# ---------------- Aldo: hoja 48x96 = 3 columnas (parado, paso A, paso B) x 4 filas (abajo, izquierda, derecha, arriba), cada cuadro 16x24
PIEL = (232, 190, 150, 255); PELO = (70, 46, 30, 255); CAMISA = (86, 120, 160, 255); PANT = (52, 56, 76, 255); ZAPATO = (36, 30, 28, 255)

def aldo_cuadro(cara, paso):
    im = img(16, 24); d = ImageDraw.Draw(im)
    # piernas
    pie_i, pie_d = 0, 0
    if paso == 1: pie_i = -1; pie_d = 1
    if paso == 2: pie_i = 1; pie_d = -1
    if cara in (1, 2):  # de lado: piernas juntas que se cruzan
        d.rectangle([6 + pie_i, 17, 9 + pie_i, 22], fill=PANT); d.rectangle([6 + pie_i, 22, 10 + pie_i, 23], fill=ZAPATO)
    else:
        d.rectangle([4, 17 + (1 if pie_i < 0 else 0), 7, 22], fill=PANT); d.rectangle([4, 22, 7, 23], fill=ZAPATO)
        d.rectangle([8, 17 + (1 if pie_d < 0 else 0), 11, 22], fill=PANT); d.rectangle([8, 22, 11, 23], fill=ZAPATO)
    # torso y brazos
    d.rectangle([4, 10, 11, 17], fill=CAMISA)
    if cara in (0, 3):
        d.rectangle([2, 11, 3, 16], fill=CAMISA); d.rectangle([12, 11, 13, 16], fill=CAMISA)
        d.point((2, 16), fill=PIEL); d.point((13, 16), fill=PIEL)
    else:
        d.rectangle([6, 11, 9, 16], fill=oscuro(CAMISA, 0.85))
    # cabeza
    d.rectangle([4, 2, 11, 10], fill=PIEL)
    # pelo y cara
    if cara == 0:
        d.rectangle([3, 1, 12, 4], fill=PELO); d.point((3, 5), fill=PELO); d.point((12, 5), fill=PELO)
        d.point((6, 7), fill=(30, 30, 40, 255)); d.point((9, 7), fill=(30, 30, 40, 255))
    elif cara == 3:
        d.rectangle([3, 1, 12, 9], fill=PELO)
    elif cara == 1:
        d.rectangle([3, 1, 12, 4], fill=PELO); d.rectangle([8, 4, 12, 8], fill=PELO); d.point((5, 7), fill=(30, 30, 40, 255))
    else:
        d.rectangle([3, 1, 12, 4], fill=PELO); d.rectangle([3, 4, 7, 8], fill=PELO); d.point((10, 7), fill=(30, 30, 40, 255))
    return im

hoja = img(48, 96)
for fila in range(4):
    for col in range(3):
        hoja.paste(aldo_cuadro(fila if fila < 4 else 0, col), (col * 16, fila * 24))
hoja.save(f'{OUT}/personajes/aldo.png')

# ---------------- vistas previas (pueblo y playa): las dibuja tools/vista_previa.py
print('arte generado:', len(TILES), 'tiles,', len(datos['edificios']), 'edificios, 1 personaje')
import subprocess, sys
subprocess.run([sys.executable, 'tools/vista_previa.py'], check=False)
