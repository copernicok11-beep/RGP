#!/usr/bin/env python3
"""Crea los 4 fotogramas del agua animada en assets/arte/tiles/:
    agua_1..4.png  (agua normal)   agua_honda_1..4.png  (mar adentro)   agua_orilla_1..4.png  (aguas bajas con espuma)
Cada fotograma es 16x16 y se repite sin costuras: las olas se desplazan 4 px por fotograma y dan la vuelta al borde,
asi que el cuadro 4 enlaza con el 1. El juego los va alternando solo; si faltan, usa agua.png fijo como antes.
No pisa archivos que ya existan (tus dibujos estan a salvo). Para rehacerlos, borra los agua_*_N.png y corre de nuevo.
Uso (desde app/):  python3 tools/generar_arte_agua.py
"""
import os
import random
from PIL import Image

T = 16
OUT = 'assets/arte/tiles'
os.makedirs(OUT, exist_ok=True)
SUBE = [0, 1, 1, 0]            # la ola sube y baja un pixel mientras avanza


def fotograma(k, base, tonos, semilla, crestas, c_cresta, c_sombra, chispas=0, c_chispa=(255, 255, 255, 255), n_ruido=12):
    im = Image.new('RGBA', (T, T), base)
    px = im.load()
    r = random.Random(semilla)                      # el "grano" del agua es igual en los 4 cuadros: no parpadea
    for _ in range(n_ruido):
        px[r.randrange(T), r.randrange(T)] = r.choice(tonos)
    for (y0, x0, largo) in crestas:                 # crestas de ola: avanzan 4 px por cuadro y dan la vuelta
        y = (y0 + SUBE[k]) % T
        for i in range(largo):
            x = (x0 + 4 * k + i) % T
            px[x, y] = c_cresta
            if i % 2 == 0:
                px[x, (y + 1) % T] = c_sombra       # sombrita bajo la cresta
    rc = random.Random(semilla * 31 + k)            # destellos: cambian de lugar en cada cuadro
    for _ in range(chispas):
        px[rc.randrange(T), rc.randrange(T)] = c_chispa
    return im


TIPOS = {
    'agua': dict(base=(62, 124, 177, 255), tonos=[(56, 114, 166, 255), (70, 134, 188, 255)], semilla=2,
                 crestas=[(4, 2, 5), (10, 9, 4)], c_cresta=(150, 200, 235, 255), c_sombra=(52, 108, 160, 255), chispas=2),
    'agua_honda': dict(base=(47, 111, 163, 255), tonos=[(41, 100, 150, 255), (54, 120, 172, 255)], semilla=12,
                       crestas=[(7, 5, 4)], c_cresta=(88, 150, 198, 255), c_sombra=(38, 94, 144, 255), chispas=1,
                       c_chispa=(170, 210, 240, 255)),
    'agua_orilla': dict(base=(105, 174, 201, 255), tonos=[(140, 205, 225, 255), (96, 164, 192, 255)], semilla=13,
                        crestas=[(3, 1, 6), (8, 8, 5), (13, 4, 4)], c_cresta=(232, 248, 252, 255),
                        c_sombra=(120, 190, 212, 255), chispas=3),
}

for nombre, cfg in TIPOS.items():
    for k in range(4):
        ruta = f'{OUT}/{nombre}_{k + 1}.png'
        if os.path.exists(ruta):
            print('ya existe, no lo toco:', ruta)
            continue
        fotograma(k, **cfg).save(ruta)
        print('creado', ruta)
