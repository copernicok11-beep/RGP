#!/usr/bin/env python3
"""Crea el arte de relleno de los objetos NUEVOS de la playa en assets/arte/tiles/.
Solo escribe los PNG nuevos (sombrillas, toallas, bote, reposera, barril, conchas); si ya existe uno con ese nombre
NO lo pisa, asi que tus dibujos propios estan a salvo. Uso (desde app/):  python3 tools/generar_arte_playa.py
"""
import os
from PIL import Image, ImageDraw

T = 16
OUT = 'assets/arte/tiles'
os.makedirs(OUT, exist_ok=True)


def img(w, h):
    return Image.new('RGBA', (w, h), (0, 0, 0, 0))


def sombrilla(c1, c2):
    im = img(T, 24); d = ImageDraw.Draw(im)
    d.ellipse([3, 20, 13, 23], fill=(0, 0, 0, 40))                       # sombra en la arena
    d.rectangle([7, 8, 8, 22], fill=(120, 84, 48, 255))                  # palo
    d.pieslice([0, 1, 15, 15], 180, 360, fill=c1, outline=(60, 40, 30, 255))   # toldo (media luna)
    for x0 in (2, 6, 10):                                                # gajos de otro color
        d.polygon([(x0, 8), (x0 + 2, 8), (x0 + 1, 2)], fill=c2)
    d.line([(0, 8), (15, 8)], fill=(60, 40, 30, 255))
    d.point((7, 0), fill=(60, 40, 30, 255)); d.point((8, 0), fill=(60, 40, 30, 255))
    return im


def toalla(c1, c2):
    im = img(T, T); d = ImageDraw.Draw(im)
    d.rectangle([2, 3, 13, 12], fill=c1, outline=(80, 60, 50, 255))
    for x in (4, 7, 10):
        d.rectangle([x, 4, x + 1, 11], fill=c2)
    d.line([(2, 13), (13, 13)], fill=(0, 0, 0, 30))                      # sombrita
    return im


def reposera():
    im = img(T, T); d = ImageDraw.Draw(im)
    d.polygon([(2, 14), (4, 6), (7, 6), (6, 11), (13, 11), (14, 14)], fill=(235, 235, 225, 255), outline=(70, 70, 80, 255))
    for x in (5, 8, 11):
        d.line([(x, 12), (x, 14)], fill=(70, 130, 190, 255))
    d.line([(4, 6), (5, 2)], fill=(70, 70, 80, 255))
    return im


def barril():
    im = img(T, T); d = ImageDraw.Draw(im)
    d.ellipse([3, 12, 13, 15], fill=(0, 0, 0, 40))
    d.rectangle([4, 4, 11, 13], fill=(140, 96, 54, 255), outline=(80, 54, 30, 255))
    d.ellipse([4, 2, 11, 6], fill=(165, 118, 70, 255), outline=(80, 54, 30, 255))
    for y in (6, 11):
        d.line([(4, y), (11, y)], fill=(70, 70, 76, 255))
    return im


def conchas():
    im = img(T, T); d = ImageDraw.Draw(im)
    d.ellipse([3, 8, 6, 10], fill=(250, 226, 214, 255), outline=(200, 150, 140, 255))
    d.ellipse([9, 5, 12, 7], fill=(255, 240, 220, 255), outline=(210, 170, 140, 255))
    d.polygon([(7, 12), (8, 10), (9, 12), (11, 12), (9, 14), (10, 15), (8, 14), (6, 15), (7, 14), (5, 12)],
              fill=(235, 120, 90, 255))                                   # estrella de mar
    return im


def barco():                                                             # 3x2 cuadros = 48x32
    im = img(48, 32); d = ImageDraw.Draw(im)
    d.ellipse([1, 25, 47, 31], fill=(0, 0, 0, 45))                       # sombra
    d.polygon([(1, 13), (47, 13), (41, 26), (8, 26)], fill=(138, 90, 50, 255), outline=(82, 52, 28, 255))   # casco
    for y in (18, 22):                                                   # tablas
        d.line([(4, y), (44, y)], fill=(104, 66, 36, 255))
    d.line([(2, 15), (46, 15)], fill=(196, 60, 50, 255), width=2)        # franja roja
    d.ellipse([1, 7, 47, 19], fill=(168, 118, 72, 255), outline=(82, 52, 28, 255))    # borde superior
    d.ellipse([4, 9, 44, 17], fill=(84, 56, 32, 255))                    # interior
    d.rectangle([21, 9, 26, 16], fill=(128, 88, 50, 255), outline=(82, 52, 28, 255))   # banco
    d.polygon([(44, 9), (47, 4), (47, 13)], fill=(168, 118, 72, 255), outline=(82, 52, 28, 255))     # proa alta
    d.line([(10, 9), (31, 2)], fill=(120, 80, 44, 255), width=2)         # remo apoyado
    d.ellipse([29, 0, 34, 4], fill=(120, 80, 44, 255))
    d.arc([36, 17, 44, 25], 0, 300, fill=(222, 206, 160, 255))           # cuerda enrollada
    return im


NUEVOS = {
    'sombrilla_roja': sombrilla((214, 62, 56, 255), (250, 244, 232, 255)),
    'sombrilla_azul': sombrilla((52, 128, 200, 255), (250, 214, 90, 255)),
    'toalla_rayas': toalla((250, 244, 232, 255), (214, 62, 56, 255)),
    'toalla_azul': toalla((90, 170, 220, 255), (250, 250, 250, 255)),
    'reposera': reposera(),
    'barril': barril(),
    'conchas': conchas(),
    'barco': barco(),
}
for nombre, im in NUEVOS.items():
    ruta = f'{OUT}/{nombre}.png'
    if os.path.exists(ruta):
        print('ya existe, no lo toco:', ruta)
    else:
        im.save(ruta)
        print('creado', ruta, im.size)
