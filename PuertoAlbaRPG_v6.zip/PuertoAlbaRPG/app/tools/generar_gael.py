#!/usr/bin/env python3
"""PROVISIONAL: dibuja a Gael (misma plantilla que Aldo, otra paleta) estilo granjero de Stardew Valley (cabeza grande, contorno oscuro, ojos de 2 px) y lo guarda en
assets/arte/personajes/gael.png = hoja 48x96: 3 columnas (parado, paso A, paso B) x 4 filas (abajo, izquierda, derecha, arriba),
cada cuadro de 16x24, con los pies en el borde de abajo. Tambien crea vista_gael.png (ampliada, solo para mirar).
Cambialo cuando tengas el sprite definitivo de Gael (misma hoja 48x96).
Uso (desde app/):  python3 tools/generar_personaje.py
"""
from PIL import Image

T, ALTO = 16, 24
PAL = {
    'H': (38, 30, 34), 'h': (70, 56, 60),                        # pelo oscuro / brillo
    'S': (222, 170, 128), 's': (190, 134, 100), 'E': (30, 22, 30), 'M': (186, 100, 96),   # piel morena
    'C': (214, 106, 58), 'c': (170, 76, 40),                     # camisa naranja / sombra
    'P': (60, 92, 128), 'p': (44, 70, 100),                      # jeans
    'B': (70, 52, 44), 'b': (48, 36, 30),                        # botas
}
CONTORNO = (52, 34, 36)

# ---- cada direccion = 17 filas de arriba (y1..y17) + 5 filas de piernas (y18..y22) por cada fotograma
TORSO_FRENTE = [
    "....CCCCCCCC....",
    "...CcCCCCCCcC...",
    "...CcCCCCCCcC...",
    "...CcCCCCCCcC...",
    "...SsCCCCCCsS...",
    "....CCCCCCCC....",
    "....PPPPPPPP....",
]
ARRIBA = {
    'frente': [
        ".....HHHHHH.....",
        "....HHHhhHHH....",
        "...HHHHHHHHHH...",
        "...HHHHHHHHHH...",
        "...HHHSSSSHHH...",
        "...HSSSSSSSSH...",
        "...HSSESSESSH...",
        "...HSSESSESSH...",
        "....SSSMMSSS....",
        ".....sSSSSs.....",
    ] + TORSO_FRENTE,
    'espalda': [
        ".....HHHHHH.....",
        "....HHHhhHHH....",
        "...HHHHHHHHHH...",
        "...HHHHHHHHHH...",
        "...HHHhHHhHHH...",
        "...HHHHHHHHHH...",
        "...HHHHHHHHHH...",
        "...HHHHHHHHHH...",
        "....HHHHHHHH....",
        ".....sSSSSs.....",
    ] + TORSO_FRENTE,
    'izquierda': [
        ".....HHHHH......",
        "....HHHhHHHH....",
        "....HHHHHHHHH...",
        "....HHHHHHHHH...",
        "....SSHHHHHHH...",
        "....SSSHHHHHH...",
        "...SSESSHHHHH...",
        "....SESSHHHHH...",
        "....SSSSSHHH....",
        "......sSSs......",
        ".....CCCCCC.....",
        ".....CCccCC.....",
        ".....CCccCC.....",
        ".....CCccCC.....",
        ".....CCsSCC.....",
        ".....CCCCCC.....",
        ".....PPPPPP.....",
    ],
}
PIERNAS = {
    'frente': [
        ["....PPPpPPPP....", "....PPPpPPPP....", "....PPPpPPPP....", "....BBBbBBBB....", "....BBBbBBBB...."],
        ["....PPPpPPPP....", "....PPPpPPPP....", "....BBBbPPPP....", "....BBBbBBBB....", "........BBBB...."],
        ["....PPPpPPPP....", "....PPPpPPPP....", "....PPPpBBBB....", "....BBBbBBBB....", "....BBBb........"],
    ],
    'izquierda': [
        [".....PPPPPP.....", ".....PPPPPP.....", ".....PPPPPP.....", "....BBBBBBB.....", "....BBBBBBB....."],
        [".....PPPPPP.....", ".....PPPPPP.....", "....PPPP.PPP....", "....BBBB.BBB....", "....BBBB........"],
        [".....PPPPPP.....", ".....PPPPPP.....", ".....PPP.PPP....", ".....BBB.BBB....", ".........BBB...."],
    ],
}
PIERNAS['espalda'] = PIERNAS['frente']


def cuadro(direccion, paso):
    clave = 'izquierda' if direccion in ('izquierda', 'derecha') else direccion
    filas = ['.' * T] + ARRIBA[clave] + PIERNAS[clave][paso] + ['.' * T]
    assert len(filas) == ALTO and all(len(f) == T for f in filas), (direccion, paso, len(filas), [len(f) for f in filas])
    im = Image.new('RGBA', (T, ALTO), (0, 0, 0, 0))
    px = im.load()
    for y, f in enumerate(filas):
        for x, ch in enumerate(f):
            if ch != '.':
                px[x, y] = PAL[ch] + (255,)
    # contorno oscuro alrededor de toda la silueta
    nuevo = im.copy(); npx = nuevo.load()
    for y in range(ALTO):
        for x in range(T):
            if px[x, y][3] == 0:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < T and 0 <= ny < ALTO and px[nx, ny][3] > 0:
                        npx[x, y] = CONTORNO + (255,)
                        break
    if direccion == 'derecha':
        nuevo = nuevo.transpose(Image.FLIP_LEFT_RIGHT)
    return nuevo


hoja = Image.new('RGBA', (3 * T, 4 * ALTO), (0, 0, 0, 0))
for fila, d in enumerate(['frente', 'izquierda', 'derecha', 'espalda']):       # orden de la hoja: abajo, izquierda, derecha, arriba
    for col in range(3):
        hoja.paste(cuadro(d, col), (col * T, fila * ALTO))
hoja.save('assets/arte/personajes/gael.png')
fondo = Image.new('RGBA', hoja.size, (94, 155, 73, 255)); fondo.alpha_composite(hoja)
fondo.resize((hoja.width * 10, hoja.height * 10), Image.NEAREST).save('vista_gael.png')
print('listo assets/arte/personajes/gael.png', hoja.size)
