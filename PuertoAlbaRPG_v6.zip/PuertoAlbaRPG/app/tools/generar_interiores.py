#!/usr/bin/env python3
"""Crea los interiores de La Marea (planta baja y casa de arriba) en assets/mapa/ (marea.txt/json, marea_arriba.txt/json).
Caracteres: # pared, . madera, , baldosa, m tapete, a alfombra, U escalera (caminable),
solidos: E estante, B barra, M mesa, F estufa/cafetera, R refri, C cama, D escritorio, O sofa, T tele, P planta, N lampara.
Uso (desde app/):  python3 tools/generar_interiores.py   -> tambien dibuja vista_interiores.png (solo para mirar).
"""
import json
from collections import deque

W, H = 18, 11
SOLIDOS = set('#EBMFRCDOTPN')


def vacio(piso='.'):
    g = [['#'] * W for _ in range(H)]
    for y in range(1, H - 1):
        for x in range(1, W - 1):
            g[y][x] = piso
    return g


def poner(g, ch, pts):
    for x, y in pts:
        g[y][x] = ch


def rect(x0, y0, x1, y1):
    return [(x, y) for y in range(y0, y1 + 1) for x in range(x0, x1 + 1)]


# ---------------- planta baja: libreria + cafe ----------------
a = vacio()
poner(a, ',', rect(10, 1, 16, 9))                       # piso del cafe
poner(a, 'E', rect(1, 1, 6, 1) + rect(2, 4, 4, 4) + rect(2, 6, 4, 6) + rect(12, 1, 13, 1))
poner(a, 'N', [(7, 1)])                                  # lampara de Ramon
poner(a, 'U', [(8, 1)])
poner(a, 'R', [(10, 1)]); poner(a, 'F', [(11, 1)])
poner(a, 'B', rect(10, 3, 15, 3))                        # mostrador (queda libre x=16 para pasar detras)
poner(a, 'M', [(11, 6), (14, 6), (12, 8)])
poner(a, 'O', [(1, 8)]); poner(a, 'P', [(1, 9), (16, 9)])
poner(a, 'a', rect(6, 6, 9, 8))
poner(a, 'm', [(8, 10), (9, 10)])
marea = a

# ---------------- casa de arriba ----------------
b = vacio()
poner(b, ',', rect(12, 6, 16, 9))                        # cocina
for y in range(1, 5):                                    # paredes de los cuartos
    b[y][7] = '#'; b[y][9] = '#'
for x in list(range(1, 7)) + list(range(10, 17)):
    b[5][x] = '#'
b[5][7] = '#'; b[5][9] = '#'
b[5][3] = '.'                                            # puerta del cuarto de Gael
b[5][11] = '.'                                           # puerta del cuarto de Aldo
poner(b, 'U', [(8, 1)])
poner(b, 'C', [(1, 1), (1, 2)]); poner(b, 'D', [(5, 1)]); poner(b, 'E', [(3, 1)]); poner(b, 'a', rect(3, 3, 4, 4))
poner(b, 'C', [(16, 1), (16, 2)]); poner(b, 'D', [(11, 1), (12, 1)]); poner(b, 'E', [(13, 1), (14, 1)]); poner(b, 'P', [(10, 4)])
poner(b, 'B', [(13, 6)]); poner(b, 'F', [(14, 6)]); poner(b, 'R', [(15, 6)]); poner(b, 'B', [(16, 6)])
poner(b, 'O', rect(3, 7, 5, 7)); poner(b, 'T', [(4, 9)]); poner(b, 'P', [(1, 9)])
poner(b, 'M', [(9, 8), (10, 8)])
poner(b, 'a', rect(2, 8, 6, 8))
arriba = b


def guardar(nombre, g):
    txt = '\n'.join(''.join(r) for r in g) + '\n'
    open(f'assets/mapa/{nombre}.txt', 'w', encoding='utf-8').write(txt)


def alcanzables(g, sx, sy):
    vis = {(sx, sy)}; q = deque([(sx, sy)])
    while q:
        x, y = q.popleft()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            n = (x + dx, y + dy)
            if n in vis or not (0 <= n[0] < W and 0 <= n[1] < H) or g[n[1]][n[0]] in SOLIDOS:
                continue
            vis.add(n); q.append(n)
    return vis


TEXTOS_MAREA = {
    'E': 'Libros apilados hasta el techo. Casi todos tienen la letra de Ramon en los margenes.',
    'B': 'El mostrador de Ramon, de madera oscura. Detras sigue el espejo roto.',
    'M': 'Una mesa pequena con un libro olvidado y una taza vacia.',
    'F': 'La cafetera de Ramon: gruñe como un viejo, pero funciona.',
    'R': 'Hay leche, mantequilla y un pastel a medias con una nota: "Es de Gael".',
    'O': 'Un sillon para leer. Huele a papel viejo y a cafe guardado.',
    'P': 'Una planta que sobrevive de milagro.',
    'N': 'La lampara de aceite de Ramon. El vidrio esta limpio. Cada tarde la prendia, y nadie sabe por que.',
    'U': 'La escalera a la casa de arriba.',
}
TEXTOS_ARRIBA = {
    'E': 'Un librero con cassettes, novelas de bolsillo y una caja de zapatos que dice "NO ABRIR, JEFE".',
    'B': 'La barra de la cocina. Hay frijoles en una olla grande y una cuchara que Gael nunca lava.',
    'M': 'La mesa del comedor. Dos platos desparejados y una servilleta con un dibujo de un perro.',
    'F': 'La estufa. Todavia huele a ajo y a algo que Gael juro que no se quemo.',
    'R': 'Frijoles en un tupper. Una nota: "NO TOCAR, jefe".',
    'O': 'El sillon donde Gael se queda dormido viendo peliculas.',
    'T': 'Una tele con videocasetera. Gael alquila peliculas los viernes.',
    'P': 'Gael le habla a esta planta. La planta ya se resigno.',
    'D': 'Un escritorio con papeles.',
    'C': 'Una cama.',
}
guardar('marea', marea)
guardar('marea_arriba', arriba)
json.dump({
    'nombre': 'La Marea', 'interior': True, 'ancho': W, 'alto': H, 'inicio': [8, 9],
    'salidas': [
        {'x': 8, 'y': 10, 'w': 2, 'h': 1, 'destino': 'pueblo', 'llegada': [15, 44]},
        {'x': 8, 'y': 1, 'w': 1, 'h': 1, 'destino': 'marea_arriba', 'llegada': [8, 2]},
    ],
    'textos': TEXTOS_MAREA, 'puntos': [], 'edificios': [],
}, open('assets/mapa/marea.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
json.dump({
    'nombre': 'Casa de arriba', 'interior': True, 'ancho': W, 'alto': H, 'inicio': [15, 2],
    'salidas': [{'x': 8, 'y': 1, 'w': 1, 'h': 1, 'destino': 'marea', 'llegada': [8, 2]}],
    'textos': TEXTOS_ARRIBA,
    'puntos': [
        {'x': 16, 'y': 1, 'accion': 'dormir'}, {'x': 16, 'y': 2, 'accion': 'dormir'},
        {'x': 1, 'y': 1, 'texto': 'La cama de Gael, siempre tendida a medias. Hay un walkman debajo de la almohada.'},
        {'x': 1, 'y': 2, 'texto': 'La cama de Gael, siempre tendida a medias. Hay un walkman debajo de la almohada.'},
        {'x': 5, 'y': 1, 'texto': 'El escritorio de Gael: cassettes, facturas del pescado y un dibujo de un perro.'},
        {'x': 11, 'y': 1, 'texto': 'Tu escritorio. Encima, la carta de Ramon y la caja de llaves sin etiqueta.'},
        {'x': 12, 'y': 1, 'texto': 'Tu escritorio. Encima, la carta de Ramon y la caja de llaves sin etiqueta.'},
        {'x': 13, 'y': 1, 'texto': 'Tus libros, todavia en cajas a medio abrir.'},
        {'x': 14, 'y': 1, 'texto': 'Tus libros, todavia en cajas a medio abrir.'},
    ],
    'edificios': [],
}, open('assets/mapa/marea_arriba.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

# ---- comprobaciones: todo lo importante se puede alcanzar
def chk(g, inicio, metas, nombre):
    ok = alcanzables(g, *inicio)
    for m in metas:
        assert m in ok, (nombre, 'no alcanzable', m)
    print(nombre, 'ok:', len(ok), 'cuadros caminables')

chk(marea, (8, 9), [(8, 2), (9, 10), (16, 2), (15, 2), (13, 2), (7, 2), (12, 7), (16, 3)], 'marea')
chk(arriba, (8, 2), [(8, 2), (15, 2), (15, 1), (3, 3), (14, 7), (4, 8), (11, 6), (9, 7), (12, 7)], 'arriba')

# ---- vista previa (solo para mirar)
try:
    from PIL import Image, ImageDraw
    col = {'#': (70, 56, 46), '.': (185, 138, 92), ',': (216, 210, 192), 'm': (155, 59, 48), 'a': (63, 108, 122), 'U': (120, 90, 60),
           'E': (110, 74, 46), 'B': (166, 124, 82), 'M': (166, 124, 82), 'F': (140, 143, 150), 'R': (230, 235, 239), 'C': (78, 110, 150),
           'D': (122, 82, 50), 'O': (140, 63, 74), 'T': (48, 52, 58), 'P': (60, 130, 70), 'N': (210, 160, 60)}
    S = 24
    im = Image.new('RGB', (W * S * 2 + 10, H * S), (0, 0, 0)); d = ImageDraw.Draw(im)
    for k, g in enumerate((marea, arriba)):
        for y in range(H):
            for x in range(W):
                d.rectangle([k * (W * S + 10) + x * S, y * S, k * (W * S + 10) + x * S + S - 1, y * S + S - 1], fill=col[g[y][x]])
    im.save('vista_interiores.png')
except Exception as e:
    print('sin vista previa', e)
