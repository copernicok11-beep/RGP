#!/usr/bin/env python3
"""Genera los mapas de Puerto Alba en assets/mapa/ (desde la carpeta app/):  python3 tools/generar_mapa.py

  pueblo.txt + edificios.json  -> el pueblo, 120x110 cuadros. Ahora es un pueblo ORGANICO: calles que serpentean,
                                  casas sueltas, senderos que nacen de cada puerta, huertas viejas, murallas caidas.
  playa.txt  + playa.json      -> la playa, 90x50 cuadros, con sombrillas, toallas, un bote varado, barriles y conchas.

Leyenda del suelo y objetos:
  . pasto   ~ agua   a agua honda   e agua de orilla   s arena   = camino   p plaza (piedra)   m madera (muelle/puente)
  T arbol(solido)  F fuente(solido)  L farola(solido)  b banca(solido)  C cabina(solido)
  f flores  r roca(solido)  v valla(solido)  W edificio(solido)  D puerta
  --- nuevos (playa) ---
  S sombrilla roja(solido)  Z sombrilla azul(solido)  H reposera(solido)  K barril(solido)
  B barco varado 3x2 (solido)   o toalla de rayas (se pisa)  q toalla azul (se pisa)  h conchas (se pisa)
El agua honda 'a' y la de orilla 'e' las pone solo profundidad() segun la distancia a la costa: dibuja siempre '~'.
Los objetos no llevan suelo propio: el juego les pone el de los cuadros vecinos.

Cada JSON puede traer "salidas": rectangulos (en cuadros) que, al pisarlos, llevan a otra zona.
  {"x":54,"y":0,"w":12,"h":2,"destino":"playa","llegada":[45,46]}   (llegada = cuadro donde aparece Aldo)

Para otro pueblo distinto cambia SEMILLA (mas abajo): misma receta, otro resultado.
"""
import heapq, json, math, os, random
from collections import deque

SEMILLA = 1996
SOLIDOS = '~aeTFLbCrvWDSZHKB'          # igual que Mapa.solidos en lib/mapa.dart


# ------------------------------------------------------------------ utilidades
class Mapa:
    def __init__(self, w, h, base='.'):
        self.w, self.h = w, h
        self.g = [[base] * w for _ in range(h)]

    def dentro(self, x, y):
        return 0 <= x < self.w and 0 <= y < self.h

    def rect(self, x0, y0, x1, y1, ch):
        for y in range(max(0, y0), min(self.h - 1, y1) + 1):
            for x in range(max(0, x0), min(self.w - 1, x1) + 1):
                self.g[y][x] = ch

    def get(self, x, y):
        return self.g[y][x] if self.dentro(x, y) else '#'

    def put(self, x, y, ch, sobre='.'):
        """Pone ch solo si el cuadro actual esta en 'sobre'."""
        if self.dentro(x, y) and self.g[y][x] in sobre:
            self.g[y][x] = ch
            return True
        return False

    def texto(self):
        return '\n'.join(''.join(f) for f in self.g) + '\n'


def profundidad(m, honda):
    """Convierte '~' en 'e' (orilla, a 1 cuadro de tierra), '~' (media) o 'a' (honda, a 'honda' cuadros o mas)."""
    dist = [[-1] * m.w for _ in range(m.h)]
    q = deque()
    for y in range(m.h):
        for x in range(m.w):
            if m.g[y][x] not in '~m':           # tierra (el muelle 'm' cuenta como agua)
                dist[y][x] = 0
                q.append((x, y))
    while q:
        x, y = q.popleft()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)):
            nx, ny = x + dx, y + dy
            if m.dentro(nx, ny) and dist[ny][nx] < 0:
                dist[ny][nx] = dist[y][x] + 1
                q.append((nx, ny))
    for y in range(m.h):
        for x in range(m.w):
            if m.g[y][x] == '~':
                d = dist[y][x]
                m.g[y][x] = 'e' if d == 1 else ('a' if d >= honda else '~')


def alcanzables(m, origen):
    """Cuadros a los que se puede llegar caminando desde 'origen' (4 direcciones)."""
    vis = {origen}
    q = deque([origen])
    while q:
        x, y = q.popleft()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            n = (x + dx, y + dy)
            if n not in vis and m.dentro(*n) and m.g[n[1]][n[0]] not in SOLIDOS:
                vis.add(n)
                q.append(n)
    return vis


# ================================================================== PUEBLO
W, H = 120, 110
pueblo = Mapa(W, H)
rng = random.Random(SEMILLA)
FASE = [rng.uniform(0, 6.283) for _ in range(8)]


def ruido(x, y):
    """Ruido suave en [-1, 1] para repartir bosques, flores y desgaste sin patrones repetidos."""
    return (math.sin(x / 9.0 + FASE[0]) + math.sin(y / 7.0 + FASE[1])
            + math.sin((x + y) / 11.0 + FASE[2]) + math.sin((x - y) / 8.0 + FASE[3])) / 4.0


def spline(pts, paso=0.6):
    """Curva suave (Catmull-Rom) que pasa por los puntos."""
    P = [pts[0]] + list(pts) + [pts[-1]]
    out = []
    for i in range(1, len(P) - 2):
        p0, p1, p2, p3 = P[i - 1], P[i], P[i + 1], P[i + 2]
        n = max(2, int(math.hypot(p2[0] - p1[0], p2[1] - p1[1]) / paso))
        for k in range(n):
            t = k / n
            def c(a, b, cc, d):
                return 0.5 * (2 * b + (-a + cc) * t + (2 * a - 5 * b + 4 * cc - d) * t * t + (-a + 3 * b - 3 * cc + d) * t ** 3)
            out.append((c(p0[0], p1[0], p2[0], p3[0]), c(p0[1], p1[1], p2[1], p3[1])))
    out.append(pts[-1])
    return out


def camino(m, pts, ancho=2, tremor=0.0, sobre='.'):
    """Dibuja un camino de tierra que serpentea entre los puntos. Devuelve los cuadros centrales."""
    res = []
    for i, (fx, fy) in enumerate(spline(pts)):
        x = int(round(fx + tremor * math.sin(i / 6.0 + FASE[4])))
        y = int(round(fy + tremor * 0.6 * math.sin(i / 7.0 + FASE[5])))
        a = ancho + (1 if rng.random() < 0.04 else 0)
        for oy in range(a):
            for ox in range(a):
                m.put(x - a // 2 + ox, y - a // 2 + oy, '=', sobre)
        res.append((x, y))
    return res


def elipse(m, cx, cy, rx, ry, ch, ruido_borde=0.25):
    for y in range(int(cy - ry) - 2, int(cy + ry) + 3):
        for x in range(int(cx - rx) - 2, int(cx + rx) + 3):
            r = rng.uniform(-ruido_borde, ruido_borde)
            if ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2 <= 1.0 + r:
                m.put(x, y, ch, '.')


# (id, nombre, x, y, ancho, alto, color_techo, color_pared)  -- mismos ids y tamanos de siempre:
# el arte de assets/arte/edificios/ sigue valiendo sin tocar nada. x,y son la posicion DESEADA:
# si ahi ya hay un camino o un estanque, el edificio se corre al hueco mas cercano.
BUILDINGS = [
    ('estacion',     'Estación de rescate', 9, 15, 10, 6, '#C0562B', '#E8DCC0'),
    ('radio',        'Radio Don Beto',      31, 18, 6, 5, '#4F6D7A', '#D9CBB0'),
    ('tinta',        'Tinta Salada',        43, 14, 6, 5, '#3B3B58', '#CFC3B1'),
    ('bar',          'Bar Cielo Abierto',   77, 17, 9, 6, '#8E3B6B', '#E6D5C3'),
    ('faro_dorado',  'El Faro Dorado',      101, 11, 10, 6, '#B8862B', '#F0E4C8'),
    ('marea',        'La Marea',            9, 38, 12, 8, '#2A6F8F', '#EADFC8'),
    ('clinica',      'Clínica',             29, 35, 8, 8, '#4E8F6A', '#F2F0E8'),
    ('voz',          'La Voz del Puerto',   74, 37, 8, 8, '#7A5A3A', '#DCCFB8'),
    ('iglesia',      'Iglesia',             68, 28, 10, 7, '#7B7B86', '#ECE7DD'),
    ('mercado',      'Mercado de Chela',    39, 31, 11, 7, '#D49A2A', '#E9DDB9'),
    ('hostal',       'Hostal Brisa',        44, 56, 10, 7, '#A84A3A', '#EFE0C6'),
    ('vivero',       'Vivero Raíces',       84, 57, 11, 7, '#3E7A3E', '#DDE5C8'),
    ('casa_lucas',   'Casa de Lucas',       9, 58, 6, 5, '#6B7F9A', '#E3D7C4'),
    ('casa_adrian',  'Casa de Adrián',      13, 77, 6, 5, '#5A5A66', '#E3D7C4'),
    ('casa_valeria', 'Casa de Valeria',     35, 77, 6, 5, '#B25A3A', '#E3D7C4'),
    ('casa_noa',     'Casa de Noa',         70, 78, 6, 5, '#5FA39A', '#E3D7C4'),
    ('casa_camila',  'Casa de Camila',      101, 62, 6, 5, '#8A6BA8', '#E3D7C4'),
    ('casa_elias',   'Casa de Elías',       104, 91, 6, 5, '#C0526B', '#E3D7C4'),
]

# --- 1) malecon viejo: baranda con huecos, paseo de piedra irregular que se gasta hacia los lados
for x in range(W):
    pueblo.g[0][x] = 'v' if rng.random() > 0.13 else '.'
pueblo.rect(54, 0, 65, 1, 's')                      # bajada a la playa
for x in range(4, W - 4):
    if 26 <= x <= 94:
        grosor = 3 if ruido(x, 0) > -0.1 else 2
        for y in range(2, 2 + grosor):
            pueblo.g[y][x] = 'p'
    else:
        yy = 3 + (1 if ruido(x, 5) > 0 else 0)
        for y in (yy, yy + 1):
            pueblo.g[y][x] = '='

# --- 2) calles: serpentean, algunas se acaban solas (como en un pueblo que fue creciendo sin plano)
avenida = camino(pueblo, [(59, 4), (62, 14), (57, 24), (60, 34), (56, 46), (61, 58), (57, 70), (62, 82), (58, 94), (60, 106)], 3, 1.2)
CALLES = [
    [(9, 29), (18, 23), (31, 28), (44, 22), (59, 26), (73, 21), (87, 28), (101, 22), (110, 26)],       # camino de la costa
    [(8, 52), (19, 46), (33, 53), (47, 48), (59, 48), (71, 53), (88, 46), (103, 53)],                  # camino medio (se pierde al este)
    [(59, 70), (73, 66), (88, 73), (103, 66), (112, 70)],                                             # sur, lado este
    [(59, 72), (47, 67), (31, 74), (17, 68)],                                                         # sur, lado oeste (termina en un huerto)
    [(40, 104), (59, 99), (78, 104), (98, 98), (112, 103)],                                           # camino del fondo
    [(22, 29), (26, 40), (20, 52), (25, 64)],                                                         # calle vieja (oeste, se pierde)
    [(97, 24), (92, 37), (99, 52), (94, 65), (99, 79)],                                               # calle del este
    [(16, 69), (10, 80), (13, 92)],                                                                   # callejon al sur-oeste
]
for pts in CALLES:
    camino(pueblo, pts, 2, 1.4)

# --- 3) plaza irregular (no es un rectangulo: tiene el borde gastado), cabina y fuente
PX, PY = 60, 41
for y in range(PY - 8, PY + 9):
    for x in range(PX - 12, PX + 13):
        if ((x - PX) / 9.5) ** 2 + ((y - PY) / 5.8) ** 2 <= 1.0 + rng.uniform(-0.18, 0.12):
            pueblo.put(x, y, 'p', '.=')
for (x, y) in [(PX - 1, PY - 1), (PX, PY - 1), (PX - 1, PY), (PX, PY)]:
    pueblo.g[y][x] = 'F'
pueblo.put(PX - 8, PY - 3, 'C', 'p')
for (x, y) in [(PX - 5, PY - 3), (PX + 5, PY - 3), (PX - 5, PY + 3), (PX + 5, PY + 3)]:
    pueblo.put(x, y, 'b', 'p')
for (x, y) in [(PX - 7, PY - 4), (PX + 7, PY - 4), (PX - 7, PY + 4), (PX + 7, PY + 4)]:
    pueblo.put(x, y, 'L', 'p')

# --- 4) estanques con forma de charco (dos elipses pegadas) y un mirador al norte
elipse(pueblo, 32, 61, 8, 5, '~'); elipse(pueblo, 36, 63, 5, 3.5, '~'); elipse(pueblo, 28, 59, 4, 3, '~')
elipse(pueblo, 88, 92, 8, 4.5, '~'); elipse(pueblo, 84, 94, 5, 3, '~')
for y in range(8, 13):
    for x in range(30, 42):
        if ((x - 36) / 6.5) ** 2 + ((y - 10) / 2.8) ** 2 <= 1.0 + rng.uniform(-0.15, 0.1):
            pueblo.put(x, y, 'p', '.')
pueblo.put(33, 10, 'b', 'p'); pueblo.put(39, 10, 'b', 'p'); pueblo.put(31, 9, 'L', 'p'); pueblo.put(41, 9, 'L', 'p')

OCULTOS = {'estacion'}      # edificios que ya no viven en el pueblo (la estacion de rescate esta en la playa)

# --- 5) edificios: buscan su sitio sin pisar caminos ni agua; cada uno reserva un margen
edif = []
reservado = set()


def colocar(b):
    i, nom, x, y, w, h, ct, cp = b
    prueba = sorted(((dx, dy) for dx in range(-8, 9) for dy in range(-6, 7)),
                    key=lambda d: (abs(d[0]) + abs(d[1]) + rng.random() * 2))
    for dx, dy in prueba:
        X, Y = x + dx, y + dy
        if X < 6 or X + w > W - 6 or Y < 7 or Y + h > H - 8:
            continue
        ok = True
        for yy in range(Y - 1, Y + h + 2):
            for xx in range(X - 1, X + w + 1):
                if (xx, yy) in reservado or not pueblo.dentro(xx, yy):
                    ok = False
                    break
                c = pueblo.g[yy][xx]
                dentro_ = Y <= yy < Y + h and X <= xx < X + w
                if (dentro_ and c != '.') or (not dentro_ and c not in '.=pf'):
                    ok = False
                    break
            if not ok:
                break
        if ok:
            return X, Y
    raise SystemExit('no encontre sitio para ' + i)


for b in BUILDINGS:
    i, nom, x, y, w, h, ct, cp = b
    x, y = colocar(b)
    dx = x + w // 2
    if i not in OCULTOS:
        for yy in range(y, y + h):
            for xx in range(x, x + w):
                pueblo.g[yy][xx] = 'W'
        pueblo.g[y + h - 1][dx] = 'D'
    for ax in (dx - 1, dx, dx + 1):               # el felpudo de tierra frente a la puerta
        pueblo.put(ax, y + h, '=', '.f')
    edif.append(dict(id=i, nombre=nom, x=x, y=y, w=w, h=h, techo=ct, pared=cp, puerta=[dx, y + h - 1]))
    for yy in range(y - 1, y + h + 3):
        for xx in range(x - 1, x + w + 1):
            reservado.add((xx, yy))


# --- 6) senderos que nacen de cada puerta y buscan el camino mas cercano (zigzaguean solos)
RED = '=pms'


def red_principal():
    vis = {(59, 5)}
    q = deque([(59, 5)])
    while q:
        x, y = q.popleft()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            n = (x + dx, y + dy)
            if n not in vis and pueblo.dentro(*n) and pueblo.g[n[1]][n[0]] in RED:
                vis.add(n)
                q.append(n)
    return vis


def conectar(origen, ancho=2):
    comp = red_principal()
    if origen in comp:
        return
    coste_de = {'.': 1.0, 'f': 1.3, 'r': 3.0, '~': 9.0, 'm': 1.0, '=': 0.7, 'p': 1.0, 's': 1.0}
    dist = {origen: 0.0}
    prev = {}
    pq = [(0.0, origen)]
    fin = None
    while pq:
        d, (x, y) = heapq.heappop(pq)
        if d > dist[(x, y)]:
            continue
        if (x, y) in comp:
            fin = (x, y)
            break
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            n = (x + dx, y + dy)
            if not pueblo.dentro(*n) or n[1] < 3 or n[0] < 2 or n[0] > W - 3 or n[1] > H - 4:
                continue
            c = pueblo.g[n[1]][n[0]]
            if c not in coste_de:
                continue
            nd = d + coste_de[c] * (1.0 + rng.random() * 1.6)
            if nd < dist.get(n, 1e18):
                dist[n] = nd
                prev[n] = (x, y)
                heapq.heappush(pq, (nd, n))
    if fin is None:
        print('  aviso: sin camino desde', origen)
        return
    n = fin
    while n != origen:
        for oy in range(ancho):
            for ox in range(ancho):
                x, y = n[0] + ox, n[1] + oy
                c = pueblo.get(x, y)
                if c == '~':
                    pueblo.g[y][x] = 'm'
                elif c in '.fr':
                    pueblo.g[y][x] = '='
        n = prev[n]


for e in edif:
    conectar((e['puerta'][0], e['y'] + e['h']))
conectar((36, 13))                                  # mirador

# --- 7) muelles de pesca y la cancha vieja
def muelle(x, y, dy, largo, ancho=2):
    yy = y
    while pueblo.dentro(x, yy) and pueblo.g[yy][x] != '~':
        yy += dy
    if not pueblo.dentro(x, yy):
        return
    for k in range(-1, largo):
        for ox in range(ancho):
            pueblo.put(x + ox, yy + k * dy, 'm', '.~=')
    conectar((x, yy - dy))


muelle(32, 70, -1, 5)                               # estanque oeste: desde el sur hacia el norte
muelle(88, 84, +1, 4)                               # estanque sur: desde el norte hacia el sur

for y in range(51, 59):                             # cancha vieja (este)
    for x in range(100, 112):
        pueblo.put(x, y, 'p', '.')
for (x, y) in [(101, 53), (110, 53), (101, 57), (110, 57)]:
    pueblo.put(x, y, 'b', 'p')
conectar((105, 59))

# --- 8) el tiempo: los bordes de las calles se desgastan, aparecen charcos de tierra
copia = [fila[:] for fila in pueblo.g]
for y in range(5, H - 5):
    for x in range(4, W - 4):
        if copia[y][x] == '.' and (x, y) not in reservado:
            if any(copia[y + dy][x + dx] == '=' for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))) and rng.random() < 0.07:
                pueblo.g[y][x] = '='
for _ in range(5):                                  # manchones de tierra pisada sueltos
    cx, cy = rng.randrange(8, W - 8), rng.randrange(8, H - 10)
    for _ in range(rng.randrange(5, 14)):
        pueblo.put(cx + rng.randint(-2, 2), cy + rng.randint(-1, 1), '=', '.')

# --- 9) huertas y corrales viejos: vallas con tablas que faltan
def libre(x0, y0, x1, y1):
    n = ok = 0
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            n += 1
            ok += pueblo.dentro(x, y) and (x, y) not in reservado and pueblo.g[y][x] == '.'
    return ok / n


def cerca_vieja(x0, y0, x1, y1, falta=0.2, flores=0.3):
    if libre(x0, y0, x1, y1) < 0.88:
        return False
    puerta = rng.choice([(rng.randint(x0 + 2, x1 - 2), y1), (x0, rng.randint(y0 + 2, y1 - 2))])
    for x in range(x0, x1 + 1):
        for y in (y0, y1):
            if (x, y) != puerta and rng.random() > falta:
                pueblo.put(x, y, 'v', '.')
    for y in range(y0, y1 + 1):
        for x in (x0, x1):
            if (x, y) != puerta and rng.random() > falta:
                pueblo.put(x, y, 'v', '.')
    for y in range(y0 + 1, y1):
        for x in range(x0 + 1, x1):
            if rng.random() < flores:
                pueblo.put(x, y, 'f', '.')
    return True


hechas = 0
for (x0, y0, x1, y1) in [(6, 29, 17, 35), (7, 54, 17, 56), (26, 83, 33, 90), (46, 84, 56, 93), (64, 82, 80, 90),
                         (62, 57, 72, 64), (78, 74, 90, 82), (98, 77, 111, 85), (100, 31, 113, 40), (4, 90, 18, 97),
                         (70, 4, 82, 4), (44, 104, 52, 104), (104, 44, 114, 49), (62, 6, 74, 14)]:
    if y1 - y0 >= 3 and cerca_vieja(x0, y0, x1, y1, falta=rng.choice((0.12, 0.25, 0.4)), flores=rng.choice((0.15, 0.4, 0.6))):
        hechas += 1
# muros de piedra caidos (lineas de rocas con huecos)
for _ in range(9):
    x, y = rng.randrange(8, W - 14), rng.randrange(10, H - 14)
    horiz = rng.random() < 0.5
    for k in range(rng.randrange(5, 12)):
        px, py = (x + k, y) if horiz else (x, y + k)
        if rng.random() < 0.82 and (px, py) not in reservado:
            pueblo.put(px, py, 'r', '.')

# --- 10) bosque con manchas (no parejo), alamedas sueltas, flores silvestres
def arbol(x, y):
    if (x, y) in reservado:
        return False
    return pueblo.put(x, y, 'T', '.')


for y in range(5, H):                               # bosque de borde, con el ancho cambiante
    ancho_izq = 3 + int(2.5 * (ruido(0, y) + 1))
    ancho_der = 3 + int(2.5 * (ruido(W, y + 20) + 1))
    for x in range(W):
        if x < ancho_izq or x >= W - ancho_der:
            if x <= 1 or x >= W - 2 or rng.random() < 0.72:
                arbol(x, y)
for x in range(W):                                  # bosque sur
    alto = 3 + int(2.5 * (ruido(x, H) + 1))
    for y in range(H - alto, H):
        if y >= H - 2 or rng.random() < 0.72:
            arbol(x, y)
for y in range(5, H - 5):                           # arboledas: manchas donde el ruido sube
    for x in range(4, W - 4):
        n = ruido(x * 1.15, y * 1.15)
        p = 0.035 + (0.7 * (n - 0.05) if n > 0.05 else 0.0)
        if rng.random() < p:
            arbol(x, y)
for t in range(8, 100, 5):                          # alameda torcida hacia la playa
    arbol(55 + rng.randint(-1, 0), t) if t < 24 else None
    arbol(65 + rng.randint(0, 1), t) if t < 24 else None
for _ in range(160):                                # frutales sueltos cerca de las casas
    e = rng.choice(edif)
    arbol(e['x'] + rng.randint(-5, e['w'] + 4), e['y'] + rng.randint(-3, e['h'] + 3))
for y in range(5, H - 5):                           # flores silvestres en manchas
    for x in range(4, W - 4):
        if ruido(x * 0.8 + 40, y * 0.8) > 0.28 and rng.random() < 0.30:
            pueblo.put(x, y, 'f', '.')
for _ in range(500):                                # flores y rocas sueltas
    x, y = rng.randrange(4, W - 4), rng.randrange(5, H - 5)
    if (x, y) not in reservado and pueblo.g[y][x] == '.':
        pueblo.g[y][x] = 'f' if rng.random() < 0.75 else 'r'

# --- 11) farolas viejas: pocas, y solo donde hay vida (avenida, plaza, puertas)
for i in range(10, len(avenida), 16):
    x, y = avenida[i]
    lado = -3 if (i // 16) % 2 == 0 else 3
    pueblo.put(x + lado, y, 'L', '.')
for x in range(30, 92, 11):
    pueblo.put(x, 1, 'L', '.')
for x in (38, 70, 86):
    if pueblo.g[4][x] == 'p':
        pueblo.put(x, 2, 'b', 'p')
for e in edif:
    if rng.random() < 0.6:
        pueblo.put(e['puerta'][0] + rng.choice((-3, 3)), e['y'] + e['h'], 'L', '.')

# --- el solar donde estaba la estacion: ahora es una huerta vieja con su porton
solar = next(e for e in edif if e['id'] in OCULTOS)
r2 = random.Random(SEMILLA + 7)
sx, sy, sw, sh = solar['x'], solar['y'], solar['w'], solar['h']
for x in range(sx, sx + sw):
    for y in (sy, sy + sh - 1):
        if abs(x - (sx + sw // 2)) > 1 and r2.random() > 0.2:
            pueblo.put(x, y, 'v', '.f')
for y in range(sy, sy + sh):
    for x in (sx, sx + sw - 1):
        if r2.random() > 0.2:
            pueblo.put(x, y, 'v', '.f')
for y in range(sy + 1, sy + sh - 1):
    for x in range(sx + 1, sx + sw - 1):
        if r2.random() < 0.45:
            pueblo.put(x, y, 'f', '.')
for (x, y) in [(sx + 2, sy + 1), (sx + sw - 3, sy + 1), (sx + sw // 2, sy + 2)]:
    pueblo.put(x, y, 'T', '.f')


def liberar(m, objetos='TLrb'):
    """Quita arboles, farolas, rocas y bancas que dejarian un camino de 1 solo cuadro (o lo tapan)."""
    quitados = 0
    cambio = True
    while cambio:
        cambio = False
        for y in range(m.h):
            for x in range(m.w):
                if m.g[y][x] not in objetos:
                    continue
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    if m.get(x + dx, y + dy) in '=pm':
                        lado_opuesto = m.get(x + 2 * dx, y + 2 * dy)
                        if lado_opuesto in SOLIDOS or lado_opuesto == '#':
                            m.g[y][x] = '.'
                            quitados += 1
                            cambio = True
                            break
    return quitados


print('  obstaculos quitados de los caminos:', liberar(pueblo))

profundidad(pueblo, 4)
e_marea = next(e for e in edif if e['id'] == 'marea')
inicio_pueblo = [e_marea['puerta'][0], e_marea['y'] + e_marea['h']]       # frente a La Marea
salida_playa = dict(x=54, y=0, w=12, h=2, destino='playa', llegada=[45, 46])

# --- comprobacion: se puede llegar a TODAS las puertas, a la playa y a los muelles
alc = alcanzables(pueblo, tuple(inicio_pueblo))
edif = [e for e in edif if e['id'] not in OCULTOS]
malas = [e['id'] for e in edif if (e['puerta'][0], e['y'] + e['h']) not in alc]
assert not malas, 'puertas sin camino: %s' % malas
assert (59, 1) in alc and (59, 4) in alc, 'la bajada a la playa quedo aislada'
print('  pueblo: todas las puertas son alcanzables;', hechas, 'huertas/corrales')

open('assets/mapa/pueblo.txt', 'w', encoding='utf-8').write(pueblo.texto())
json.dump(dict(nombre='Puerto Alba', ancho=W, alto=H, inicio=inicio_pueblo, salidas=[salida_playa], edificios=edif),
          open('assets/mapa/edificios.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

# ================================================================== PLAYA
PW, PH = 90, 50
playa = Mapa(PW, PH, 's')


def orilla(x):
    """Fila donde termina el agua en la columna x (la costa ondula)."""
    return int(15 + 2.2 * math.sin(x / 7.0) + 1.5 * math.sin(x / 3.1 + 1.0))


for x in range(PW):
    playa.rect(x, 0, x, orilla(x), '~')
for x in range(PW):                         # franja de dunas con pasto abajo
    tope = 40 + int(2 * math.sin(x / 5.0 + 2.0))
    playa.rect(x, tope, x, PH - 1, '.')
playa.rect(43, 36, 48, PH - 1, '=')         # sendero desde el pueblo hasta el muelle
playa.rect(44, 5, 47, orilla(45) + 4, 'm')  # muelle grande
playa.rect(18, 9, 19, orilla(18) + 2, 'm')  # muelle chico
for (x, y) in [(39, 33), (53, 33)]:
    playa.put(x, y, 'b', 's')
for (x, y) in [(41, 44), (50, 44)]:
    playa.put(x, y, 'L', 's.=')
for (x, y) in [(42, 36), (49, 36), (42, 42), (49, 42), (44, 6), (47, 6)]:
    playa.put(x, y, 'L', 's.=m')


def poner(x, y, ch, sobre='s'):
    return playa.put(x, y, ch, sobre)


# --- la estacion de rescate (salvavidas) vive en la playa: arena, frente al mar, a un lado del sendero
ESTACION = dict(id='estacion', nombre='Estación de rescate', x=52, y=22, w=10, h=6, techo='#C0562B', pared='#E8DCC0')
for yy in range(ESTACION['y'], ESTACION['y'] + ESTACION['h']):
    for xx in range(ESTACION['x'], ESTACION['x'] + ESTACION['w']):
        assert playa.g[yy][xx] == 's', ('la estacion no cabe', xx, yy)
        playa.g[yy][xx] = 'W'
_dx = ESTACION['x'] + ESTACION['w'] // 2
playa.g[ESTACION['y'] + ESTACION['h'] - 1][_dx] = 'D'
ESTACION['puerta'] = [_dx, ESTACION['y'] + ESTACION['h'] - 1]


# --- ambientacion: se pone ANTES de las rocas, que solo caen donde queda arena libre
# sombrillas con sus toallas (y alguna reposera / conchas): (x, y, tipo de sombrilla)
for k, (x, y, ch) in enumerate([(55, 30, 'S'), (60, 33, 'Z'), (66, 30, 'S'), (71, 34, 'Z'),
                                (21, 30, 'Z'), (14, 33, 'S'), (27, 35, 'S'), (79, 27, 'Z'), (8, 28, 'Z')]):
    poner(x, y, ch)
    poner(x - 1, y + 1, 'o' if k % 2 == 0 else 'q')
    poner(x + 1, y + 1, 'q' if k % 2 == 0 else 'o')
    if k % 3 == 0:
        poner(x + 2, y, 'H')
    if k % 2 == 1:
        poner(x, y + 2, 'h')
for (x, y, ch) in [(36, 26, 'o'), (51, 25, 'q'), (73, 24, 'o'), (30, 24, 'q'), (62, 25, 'o'), (12, 24, 'o')]:
    poner(x, y, ch)                          # toallas sueltas (alguien se fue a nadar)
for x in range(PW):                          # conchas en la linea de la marea
    for d in (1, 2):
        if rng.random() < 0.09:
            poner(x, orilla(x) + d, 'h')

# bote varado en la orilla, entre los dos muelles, con barriles y conchas al lado
bx = 26
by = orilla(bx + 1) + 1
while not all(playa.get(bx + i, by + j) == 's' for i in range(3) for j in range(2)):
    by += 1
for i in range(3):
    for j in range(2):
        playa.g[by + j][bx + i] = 'B'
poner(bx + 4, by + 1, 'K'); poner(bx + 5, by + 1, 'K'); poner(bx + 4, by + 2, 'h'); poner(bx - 2, by + 1, 'h')
# redes y barriles junto al muelle chico
poner(21, orilla(21) + 2, 'K'); poner(16, orilla(16) + 3, 'K'); poner(22, orilla(22) + 3, 'h')

for (x0, y0, x1, y1) in [(6, 22, 14, 27), (62, 21, 74, 27), (28, 28, 34, 32), (76, 30, 84, 35)]:
    for y in range(y0, y1 + 1):             # pozas de rocas
        for x in range(x0, x1 + 1):
            if rng.random() < 0.22:
                playa.put(x, y, 'r', 's')
for (x, y) in [(10, 12), (28, 8), (60, 10), (70, 6), (80, 12), (36, 12)]:
    playa.put(x, y, 'r', '~')               # rocas en el mar
for y in range(18, 46):                     # palmeras de los costados
    for x in list(range(0, 8)) + list(range(PW - 8, PW)):
        if playa.get(x, y) in 's.' and rng.random() < 0.05:
            playa.put(x, y, 'T', 's.')
for y in range(38, PH):
    for x in range(0, PW):
        if playa.get(x, y) == '.' and (x < 36 or x > 55) and rng.random() < 0.28:
            playa.put(x, y, 'T', '.')
        elif playa.get(x, y) == '.' and rng.random() < 0.10:
            playa.put(x, y, 'f', '.')
for x in range(10, 14):
    playa.put(x, 36, 'v', 's.')
for x in range(72, 77):
    playa.put(x, 38, 'v', 's.')

profundidad(playa, 5)
alc2 = alcanzables(playa, (45, 46))
assert (45, 30) in alc2, 'la playa quedo aislada del sendero'
assert (ESTACION['puerta'][0], ESTACION['puerta'][1] + 1) in alc2, 'la puerta de la estacion no tiene camino'
print('  playa: la estacion de rescate es alcanzable')
open('assets/mapa/playa.txt', 'w', encoding='utf-8').write(playa.texto())
json.dump(dict(nombre='Playa de Puerto Alba', ancho=PW, alto=PH, inicio=[45, 46],
               salidas=[dict(x=40, y=48, w=12, h=2, destino='pueblo', llegada=[59, 4])], edificios=[ESTACION]),
          open('assets/mapa/playa.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

print('ok pueblo', W, 'x', H, '=', W * H, 'cuadros,', len(edif), 'edificios | playa', PW, 'x', PH)
