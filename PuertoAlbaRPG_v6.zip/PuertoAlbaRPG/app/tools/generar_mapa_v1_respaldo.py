#!/usr/bin/env python3
"""Genera los mapas de Puerto Alba en assets/mapa/ (desde la carpeta app/):  python3 tools/generar_mapa.py

  pueblo.txt + edificios.json  -> el pueblo, 120x110 cuadros (~13.200, como Pelican Town)
  playa.txt  + playa.json      -> la playa, 90x50 cuadros, zona conectada al norte del pueblo

Leyenda del suelo y objetos:
  . pasto   ~ agua   a agua honda   e agua de orilla   s arena   = camino   p plaza (piedra)   m madera (muelle)
  T arbol(solido)  F fuente(solido)  L farola(solido)  b banca(solido)  C cabina(solido)
  f flores  r roca(solido)  v valla(solido)  W edificio(solido)  D puerta(se pisa)
El agua honda 'a' y la de orilla 'e' las pone solo profundidad() segun la distancia a la costa: dibuja siempre '~'.
Los objetos (T L r v f b C F) no llevan suelo propio: el juego les pone el de los cuadros vecinos.

Cada JSON puede traer "salidas": rectangulos (en cuadros) que, al pisarlos, llevan a otra zona.
  {"x":54,"y":0,"w":12,"h":2,"destino":"playa","llegada":[45,46]}   (llegada = cuadro donde aparece Aldo)
"""
import json, math, os, random

# ------------------------------------------------------------------ utilidades
class Mapa:
    def __init__(self, w, h, base='.'):
        self.w, self.h = w, h
        self.g = [[base] * w for _ in range(h)]

    def dentro(self, x, y):
        return 0 <= x < self.w and 0 <= y < self.h

    def rect(self, x0, y0, x1, y1, ch):
        for y in range(max(0, y0), min(self.h - 1, y1) + 1):
            for x in range(max(0, x0), min(self.w - 1, x1) + 1):
                self.g[y][x] = ch

    def get(self, x, y):
        return self.g[y][x] if self.dentro(x, y) else '#'

    def put(self, x, y, ch, sobre='.'):
        """Pone ch solo si el cuadro actual esta en 'sobre'."""
        if self.dentro(x, y) and self.g[y][x] in sobre:
            self.g[y][x] = ch
            return True
        return False

    def texto(self):
        return '\n'.join(''.join(f) for f in self.g) + '\n'


def profundidad(m, honda):
    """Convierte '~' en 'e' (orilla, a 1 cuadro de tierra), '~' (media) o 'a' (honda, a 'honda' cuadros o mas)."""
    from collections import deque
    dist = [[-1] * m.w for _ in range(m.h)]
    q = deque()
    for y in range(m.h):
        for x in range(m.w):
            if m.g[y][x] not in '~m':           # tierra (el muelle 'm' cuenta como agua)
                dist[y][x] = 0
                q.append((x, y))
    while q:
        x, y = q.popleft()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)):   # con diagonales: bandas parejas
            nx, ny = x + dx, y + dy
            if m.dentro(nx, ny) and dist[ny][nx] < 0:
                dist[ny][nx] = dist[y][x] + 1
                q.append((nx, ny))
    for y in range(m.h):
        for x in range(m.w):
            if m.g[y][x] == '~':
                d = dist[y][x]
                m.g[y][x] = 'e' if d == 1 else ('a' if d >= honda else '~')


# ================================================================== PUEBLO
W, H = 120, 110
pueblo = Mapa(W, H)
rng = random.Random(1996)

# (id, nombre, x, y, ancho, alto, color_techo, color_pared)  -- mismos ids y tamanos que antes:
# el arte de assets/arte/edificios/ sigue valiendo sin tocar nada.
BUILDINGS = [
    ('estacion',    'Estación de rescate', 10, 16, 10, 6, '#C0562B', '#E8DCC0'),
    ('radio',       'Radio Don Beto',      30, 17,  6, 5, '#4F6D7A', '#D9CBB0'),
    ('tinta',       'Tinta Salada',        39, 17,  6, 5, '#3B3B58', '#CFC3B1'),
    ('bar',         'Bar Cielo Abierto',   76, 16,  9, 6, '#8E3B6B', '#E6D5C3'),
    ('faro_dorado', 'El Faro Dorado',      98, 16, 10, 6, '#B8862B', '#F0E4C8'),
    ('marea',       'La Marea',             8, 36, 12, 8, '#2A6F8F', '#EADFC8'),
    ('clinica',     'Clínica',             30, 36,  8, 8, '#4E8F6A', '#F2F0E8'),
    ('voz',         'La Voz del Puerto',   76, 36,  8, 8, '#7A5A3A', '#DCCFB8'),
    ('iglesia',     'Iglesia',            100, 37, 10, 7, '#7B7B86', '#ECE7DD'),
    ('hostal',      'Hostal Brisa',         8, 59, 10, 7, '#A84A3A', '#EFE0C6'),
    ('mercado',     'Mercado de Chela',    30, 59, 11, 7, '#D49A2A', '#E9DDB9'),
    ('vivero',      'Vivero Raíces',       78, 59, 11, 7, '#3E7A3E', '#DDE5C8'),
    ('casa_lucas',  'Casa de Lucas',        8, 83,  6, 5, '#6B7F9A', '#E3D7C4'),
    ('casa_adrian', 'Casa de Adrián',      16, 83,  6, 5, '#5A5A66', '#E3D7C4'),
    ('casa_valeria', 'Casa de Valeria',    30, 83,  6, 5, '#B25A3A', '#E3D7C4'),
    ('casa_noa',    'Casa de Noa',         78, 83,  6, 5, '#5FA39A', '#E3D7C4'),
    ('casa_camila', 'Casa de Camila',      86, 83,  6, 5, '#8A6BA8', '#E3D7C4'),
    ('casa_elias',  'Casa de Elías',      100, 83,  6, 5, '#C0526B', '#E3D7C4'),
]

# --- 1) calles (la puerta de cada edificio da a una calle: y + alto == fila superior de la calle)
pueblo.rect(3, 2, 116, 4, 'p')            # malecon (paseo de piedra)
pueblo.rect(0, 0, W - 1, 1, 'v')          # baranda del malecon
pueblo.rect(54, 0, 65, 1, 's')            # bajada a la playa (hueco en la baranda)
for (y0, y1) in [(22, 23), (44, 45), (66, 67), (88, 89), (104, 105)]:
    pueblo.rect(4, y0, 115, y1, '=')      # calles este-oeste
pueblo.rect(58, 5, 61, 105, '=')          # calle central (baja del malecon)
pueblo.rect(24, 22, 25, 105, '=')         # calle oeste
pueblo.rect(94, 22, 95, 105, '=')         # calle este

# --- 2) plaza central y parque
pueblo.rect(48, 24, 71, 43, 'p')          # plaza
for (x, y) in [(59, 33), (60, 33), (59, 34), (60, 34)]:
    pueblo.g[y][x] = 'F'                  # fuente 2x2
pueblo.g[26][50] = 'C'                    # cabina
for (x, y) in [(53, 30), (66, 30), (53, 38), (66, 38)]:
    pueblo.g[y][x] = 'b'
for (x, y) in [(48, 24), (71, 24), (48, 43), (71, 43), (54, 24), (65, 24), (54, 43), (65, 43)]:
    pueblo.g[y][x] = 'L'
# kiosco redondo en el parque (sur de la plaza)
cx, cy = 59.5, 55.5
for y in range(48, 64):
    for x in range(46, 74):
        if ((x - cx) / 6.5) ** 2 + ((y - cy) / 5.0) ** 2 <= 1.0:
            pueblo.put(x, y, 'p', '.=')
for (x, y) in [(55, 53), (64, 53), (55, 58), (64, 58)]:
    pueblo.put(x, y, 'b', 'p')
# canchita deportiva (este)
pueblo.rect(98, 49, 111, 58, 'p')

# --- 3) edificios (reservan un margen para no poner arboles pegados)
edif = []
reservado = set()
for (i, nom, x, y, w, h, ct, cp) in BUILDINGS:
    for yy in range(y, y + h):
        for xx in range(x, x + w):
            assert pueblo.g[yy][xx] in '.', (i, xx, yy, pueblo.g[yy][xx])
            pueblo.g[yy][xx] = 'W'
    dx = x + w // 2
    pueblo.g[y + h - 1][dx] = 'D'
    assert pueblo.g[y + h][dx] in '=p', ('la puerta de %s no da a una calle' % i)
    edif.append(dict(id=i, nombre=nom, x=x, y=y, w=w, h=h, techo=ct, pared=cp, puerta=[dx, y + h - 1]))
    for yy in range(y - 1, y + h + 1):
        for xx in range(x - 1, x + w + 1):
            reservado.add((xx, yy))

# --- 4) agua: dos estanques con muelle de pesca
def elipse(m, cx, cy, rx, ry, ch):
    for y in range(int(cy - ry) - 1, int(cy + ry) + 2):
        for x in range(int(cx - rx) - 1, int(cx + rx) + 2):
            ruido = rng.uniform(-0.12, 0.12)
            if ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2 <= 1.0 + ruido:
                m.put(x, y, ch, '.')
elipse(pueblo, 39, 75, 9, 5.5, '~')       # estanque del barrio
for y in range(76, 82):
    for x in (37, 38):
        if pueblo.g[y][x] in '.~':
            pueblo.g[y][x] = 'm'          # muelle de pesca
elipse(pueblo, 84, 98, 9, 4.5, '~')       # estanque del sur
for (x, y) in [(75, 94), (76, 103), (93, 100), (92, 94), (82, 93)]:
    pueblo.put(x, y, 'r', '.')
pueblo.put(84, 103, 'b', '.')


# --- 4b) senderos sinuosos (rompen la cuadricula de las calles)
def sendero(m, a, b, ancho=2, ondula=0.3, sobre='.fTrv'):
    x, y = a
    for _ in range(400):
        for ox in range(ancho):
            for oy in range(ancho):
                tx, ty = x + ox, y + oy
                if m.dentro(tx, ty) and m.g[ty][tx] in sobre:
                    m.g[ty][tx] = '='
        if (x, y) == tuple(b):
            break
        dx = (b[0] > x) - (b[0] < x)
        dy = (b[1] > y) - (b[1] < y)
        if dx and dy:
            if rng.random() < 0.5: dx = 0
            else: dy = 0
        if rng.random() < ondula:               # un paso de lado
            if dx == 0: dx = rng.choice((-1, 1)); dy = 0
            elif dy == 0: dy = rng.choice((-1, 1)); dx = 0
        nx, ny = x + dx, y + dy
        if m.dentro(nx, ny) and (nx, ny) not in reservado: x, y = nx, ny
        else: x, y = x + (b[0] > x) - (b[0] < x), y

sendero(pueblo, (38, 87), (38, 82), 2, 0.0)       # camino al muelle del estanque
sendero(pueblo, (104, 46), (104, 48), 2, 0.0)     # entradas de la cancha
sendero(pueblo, (104, 65), (104, 59), 2, 0.0)
sendero(pueblo, (84, 90), (84, 93), 2, 0.0)       # estanque del sur
for y in range(94, 98):
    for x in (84, 85):
        pueblo.put(x, y, 'm', '.~')               # muelle del estanque del sur
sendero(pueblo, (28, 67), (28, 82), 2, 0.45)      # senda oeste junto al estanque
sendero(pueblo, (66, 68), (74, 86), 2, 0.5)       # senda diagonal entre calles
sendero(pueblo, (50, 68), (44, 87), 2, 0.5)
pueblo.rect(30, 7, 43, 10, 'p')                   # mirador del norte
for (x, y) in [(33, 8), (40, 8)]: pueblo.g[y][x] = 'b'
for (x, y) in [(30, 7), (43, 7), (30, 10), (43, 10)]: pueblo.g[y][x] = 'L'
sendero(pueblo, (37, 11), (37, 21), 1, 0.0)       # bajada del mirador a la avenida

# --- 5) cercas y huertas
def cerca(m, x0, y0, x1, y1, huecos=(), sobre='.'):
    for x in range(x0, x1 + 1):
        for y in (y0, y1):
            if (x, y) not in huecos: m.put(x, y, 'v', sobre)
    for y in range(y0, y1 + 1):
        for x in (x0, x1):
            if (x, y) not in huecos: m.put(x, y, 'v', sobre)
def flores_en(m, x0, y0, x1, y1, p):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            if rng.random() < p: m.put(x, y, 'f', '.')

cerca(pueblo, 7, 25, 20, 33, huecos={(13, 33), (14, 33)})            # huerta de La Marea
flores_en(pueblo, 8, 26, 19, 32, 0.45)
cerca(pueblo, 76, 50, 90, 57, huecos={(82, 57), (83, 57), (84, 57)}) # patio del vivero
flores_en(pueblo, 77, 51, 89, 56, 0.55)
cerca(pueblo, 98, 49, 111, 58, huecos={(104, 49), (105, 49), (104, 58), (105, 58)}, sobre='.p')  # reja de la cancha
for (x, y) in [(100, 51), (109, 51), (100, 56), (109, 56)]:
    pueblo.g[y][x] = 'b'
for (x0, y0, x1, y1) in [(80, 69, 90, 75), (98, 69, 108, 76), (4, 69, 14, 76)]:
    cerca(pueblo, x0, y0, x1, y1, huecos={((x0 + x1) // 2, y1)})      # huertos familiares
    flores_en(pueblo, x0 + 1, y0 + 1, x1 - 1, y1 - 1, 0.35)

# --- 6) arboles: bosque de borde, frutales, alameda y arboledas
def arbol(x, y, sobre='.'):
    if (x, y) in reservado: return False
    return pueblo.put(x, y, 'T', sobre)

for y in range(0, H):                      # bosque lateral
    for x in list(range(0, 4)) + list(range(W - 4, W)):
        if y > 4 and (x <= 1 or x >= W - 2 or rng.random() < 0.7): arbol(x, y)
for x in range(0, W):                      # bosque sur
    for y in range(106, H):
        if y >= 108 or rng.random() < 0.7: arbol(x, y)
for y in range(7, 22, 3):                  # alameda hacia la playa
    arbol(55, y); arbol(64, y)
    pueblo.put(56, y + 1, 'L', '.'); pueblo.put(63, y + 1, 'L', '.')
flores_en(pueblo, 50, 6, 54, 21, 0.25); flores_en(pueblo, 65, 6, 69, 21, 0.25)
for y in range(26, 34, 3):                 # frutales entre la clinica y la plaza
    for x in range(28, 46, 3): arbol(x, y)
for (x0, y0, x1, y1, p) in [                # arboledas y bosquecillos
        (4, 6, 22, 14, 0.30), (100, 6, 114, 14, 0.45), (74, 24, 92, 34, 0.10),
        (26, 46, 42, 57, 0.12), (4, 47, 22, 57, 0.30), (92, 47, 97, 65, 0.15),
        (112, 47, 115, 66, 0.35), (44, 46, 47, 64, 0.30), (72, 46, 75, 64, 0.30),
        (46, 68, 56, 86, 0.22), (62, 68, 76, 86, 0.22), (4, 90, 44, 103, 0.40),
        (46, 90, 56, 103, 0.28), (62, 90, 74, 103, 0.25), (96, 90, 115, 103, 0.35),
        (116 - 2, 6, 116, 105, 0.5)]:
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            if rng.random() < p: arbol(x, y)

# --- 7) farolas junto a las calles y decoracion suelta
def puede(x, y):
    return pueblo.dentro(x, y) and pueblo.g[y][x] == '.' and (x, y) not in reservado
for x in range(8, 114, 11):
    for (y0, y1) in [(22, 23), (44, 45), (66, 67), (88, 89)]:
        if puede(x, y0 - 1): pueblo.g[y0 - 1][x] = 'L'
        if puede(x + 5, y1 + 1): pueblo.g[y1 + 1][x + 5] = 'L'
for y in range(10, 104, 10):
    if puede(57, y): pueblo.g[y][57] = 'L'
    if puede(62, y + 5): pueblo.g[y + 5][62] = 'L'
for x in range(8, 114, 10):                # farolas y bancas del malecon
    pueblo.put(x, 2, 'L', 'p')
for x in (20, 36, 80, 96):
    pueblo.put(x, 3, 'b', 'p')
for _ in range(900):                       # flores y rocas sueltas
    x, y = rng.randrange(4, W - 4), rng.randrange(5, 105)
    if puede(x, y):
        pueblo.g[y][x] = 'f' if rng.random() < 0.8 else 'r'

profundidad(pueblo, 4)
inicio_pueblo = [14, 44]                   # frente a La Marea
salida_playa = dict(x=54, y=0, w=12, h=2, destino='playa', llegada=[45, 46])
open('assets/mapa/pueblo.txt', 'w', encoding='utf-8').write(pueblo.texto())
json.dump(dict(nombre='Puerto Alba', ancho=W, alto=H, inicio=inicio_pueblo, salidas=[salida_playa], edificios=edif),
          open('assets/mapa/edificios.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

# ================================================================== PLAYA
PW, PH = 90, 50
playa = Mapa(PW, PH, 's')

def orilla(x):
    """Fila donde termina el agua en la columna x (la costa ondula)."""
    return int(15 + 2.2 * math.sin(x / 7.0) + 1.5 * math.sin(x / 3.1 + 1.0))

for x in range(PW):
    playa.rect(x, 0, x, orilla(x), '~')
for x in range(PW):                         # franja de dunas con pasto abajo
    tope = 40 + int(2 * math.sin(x / 5.0 + 2.0))
    playa.rect(x, tope, x, PH - 1, '.')
playa.rect(43, 36, 48, PH - 1, '=')         # sendero desde el pueblo hasta el muelle
playa.rect(44, 5, 47, orilla(45) + 4, 'm')  # muelle grande
playa.rect(18, 9, 19, orilla(18) + 2, 'm')  # muelle chico
for (x, y) in [(39, 33), (53, 33)]:
    playa.put(x, y, 'b', 's')
for (x, y) in [(41, 44), (50, 44)]:
    playa.put(x, y, 'L', 's.=')
for (x, y) in [(42, 36), (49, 36), (42, 42), (49, 42), (45, 6), (46, 6)]:
    playa.put(x, y, 'L', 's.=m')
for (x0, y0, x1, y1) in [(6, 22, 14, 27), (62, 21, 74, 27), (28, 28, 34, 32), (76, 30, 84, 35)]:
    for y in range(y0, y1 + 1):             # pozas de rocas
        for x in range(x0, x1 + 1):
            if rng.random() < 0.22: playa.put(x, y, 'r', 's')
for (x, y) in [(10, 12), (28, 8), (60, 10), (70, 6), (80, 12), (36, 12)]:
    playa.put(x, y, 'r', '~')               # rocas en el mar
for y in range(18, 46):                     # palmeras de los costados
    for x in list(range(0, 8)) + list(range(PW - 8, PW)):
        if playa.get(x, y) in 's.' and rng.random() < 0.05: playa.put(x, y, 'T', 's.')
for y in range(38, PH):
    for x in range(0, PW):
        if playa.get(x, y) == '.' and (x < 36 or x > 55) and rng.random() < 0.28: playa.put(x, y, 'T', '.')
        elif playa.get(x, y) == '.' and rng.random() < 0.10: playa.put(x, y, 'f', '.')
for x in range(10, 14): playa.put(x, 36, 'v', 's.')
for x in range(72, 77): playa.put(x, 38, 'v', 's.')

profundidad(playa, 5)
playa_txt = playa.texto()
open('assets/mapa/playa.txt', 'w', encoding='utf-8').write(playa_txt)
json.dump(dict(nombre='Playa de Puerto Alba', ancho=PW, alto=PH, inicio=[45, 46],
               salidas=[dict(x=40, y=48, w=12, h=2, destino='pueblo', llegada=[59, 4])], edificios=[]),
          open('assets/mapa/playa.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

print('ok pueblo', W, 'x', H, '=', W * H, 'cuadros,', len(edif), 'edificios | playa', PW, 'x', PH)
