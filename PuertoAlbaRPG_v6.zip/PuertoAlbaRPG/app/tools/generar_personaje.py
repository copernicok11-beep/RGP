#!/usr/bin/env python3
"""Dibuja a Aldo estilo granjero de Stardew Valley (cabeza grande, contorno oscuro, ojos de 2 px) y lo guarda en
assets/arte/personajes/aldo.png = hoja 48x96: 3 columnas (parado, paso A, paso B) x 4 filas (abajo, izquierda, derecha, arriba),
cada cuadro de 16x24, con los pies en el borde de abajo. Tambien crea vista_aldo.png (ampliada, solo para mirar).
OJO: sobrescribe aldo.png. El dibujo anterior esta en tools/respaldo/aldo_v1.png.
Uso (desde app/):  python3 tools/generar_personaje.py
"""
from PIL import Image

T, ALTO = 16, 24
PAL = {
    'H': (96, 60, 36), 'h': (134, 92, 58),                       # pelo / brillo
    'S': (242, 202, 160), 's': (214, 160, 124), 'E': (36, 28, 40), 'M': (196, 112, 104),   # piel, sombra, ojos, boca
    'C': (84, 134, 190), 'c': (60, 100, 150),                    # camisa / sombra
    'P': (72, 78, 118), 'p': (52, 56, 90),                       # pantalon / sombra
    'B': (96, 62, 42), 'b': (66, 42, 30),                        # botas / sombra
}
CONTORNO = (52, 34, 36)

# ---- cada direccion = 17 filas de arriba (y1..y17) + 5 filas de piernas (y18..y22) por cada fotograma
TORSO_FRENTE = [
    "....CCCCCCCC....",
    "...CcCCCCCCcC...",
    "...CcCCCCCCcC...",
    "...CcCCCCCCcC...",
    "...SsCCCCCCsS...",
    "....CCCCCCCC....",
    "....PPPPPPPP....",
]
ARRIBA = {
    'frente': [
        ".....HHHHHH.....",
        "....HHHhhHHH....",
        "...HHHHHHHHHH...",
        "...HHHHHHHHHH...",
        "...HHHSSSSHHH...",
        "...HSSSSSSSSH...",
        "...HSSESSESSH...",
        "...HSSESSESSH...",
        "....SSSMMSSS....",
        ".....sSSSSs.....",
    ] + TORSO_FRENTE,
    'espalda': [
        ".....HHHHHH.....",
        "....HHHhhHHH....",
        "...HHHHHHHHHH...",
        "...HHHHHHHHHH...",
        "...HHHhHHhHHH...",
        "...HHHHHHHHHH...",
        "...HHHHHHHHHH...",
        "...HHHHHHHHHH...",
        "....HHHHHHHH....",
        ".....sSSSSs.....",
    ] + TORSO_FRENTE,
    'izquierda': [
        ".....HHHHH......",
        "....HHHhHHHH....",
        "....HHHHHHHHH...",
        "....HHHHHHHHH...",
        "....SSHHHHHHH...",
        "....SSSHHHHHH...",
        "...SSESSHHHHH...",
        "....SESSHHHHH...",
        "....SSSSSHHH....",
        "......sSSs......",
        ".....CCCCCC.....",
        ".....CCccCC.....",
        ".....CCccCC.....",
        ".....CCccCC.....",
        ".....CCsSCC.....",
        ".....CCCCCC.....",
        ".....PPPPPP.....",
    ],
}
PIERNAS = {
    'frente': [
        ["....PPPpPPPP....", "....PPPpPPPP....", "....PPPpPPPP....", "....BBBbBBBB....", "....BBBbBBBB...."],
        ["....PPPpPPPP....", "....PPPpPPPP....", "....BBBbPPPP....", "....BBBbBBBB....", "........BBBB...."],
        ["....PPPpPPPP....", "....PPPpPPPP....", "....PPPpBBBB....", "....BBBbBBBB....", "....BBBb........"],
    ],
    'izquierda': [
        [".....PPPPPP.....", ".....PPPPPP.....", ".....PPPPPP.....", "....BBBBBBB.....", "....BBBBBBB....."],
        [".....PPPPPP.....", ".....PPPPPP.....", "....PPPP.PPP....", "....BBBB.BBB....", "....BBBB........"],
        [".....PPPPPP.....", ".....PPPPPP.....", ".....PPP.PPP....", ".....BBB.BBB....", ".........BBB...."],
    ],
}
PIERNAS['espalda'] = PIERNAS['frente']


def cuadro(direccion, paso):
    clave = 'izquierda' if direccion in ('izquierda', 'derecha') else direccion
    filas = ['.' * T] + ARRIBA[clave] + PIERNAS[clave][paso] + ['.' * T]
    assert len(filas) == ALTO and all(len(f) == T for f in filas), (direccion, paso, len(filas), [len(f) for f in filas])
    im = Image.new('RGBA', (T, ALTO), (0, 0, 0, 0))
    px = im.load()
    for y, f in enumerate(filas):
        for x, ch in enumerate(f):
            if ch != '.':
                px[x, y] = PAL[ch] + (255,)
    # contorno oscuro alrededor de toda la silueta
    nuevo = im.copy(); npx = nuevo.load()
    for y in range(ALTO):
        for x in range(T):
            if px[x, y][3] == 0:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < T and 0 <= ny < ALTO and px[nx, ny][3] > 0:
                        npx[x, y] = CONTORNO + (255,)
                        break
    if direccion == 'derecha':
        nuevo = nuevo.transpose(Image.FLIP_LEFT_RIGHT)
    return nuevo


hoja = Image.new('RGBA', (3 * T, 4 * ALTO), (0, 0, 0, 0))
for fila, d in enumerate(['frente', 'izquierda', 'derecha', 'espalda']):       # orden de la hoja: abajo, izquierda, derecha, arriba
    for col in range(3):
        hoja.paste(cuadro(d, col), (col * T, fila * ALTO))
hoja.save('assets/arte/personajes/aldo.png')
fondo = Image.new('RGBA', hoja.size, (94, 155, 73, 255)); fondo.alpha_composite(hoja)
fondo.resize((hoja.width * 10, hoja.height * 10), Image.NEAREST).save('vista_aldo.png')
print('listo assets/arte/personajes/aldo.png', hoja.size)
