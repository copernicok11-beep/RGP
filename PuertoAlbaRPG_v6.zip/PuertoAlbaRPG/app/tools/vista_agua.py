#!/usr/bin/env python3
"""Genera vista_agua.gif: un trozo de la playa con el agua animada (misma regla que el juego). Uso (desde app/): python3 tools/vista_agua.py"""
from PIL import Image
import importlib.util, sys
spec = importlib.util.spec_from_file_location('vp', 'tools/vista_previa.py')
T = 16
filas = [l for l in open('assets/mapa/playa.txt', encoding='utf-8').read().split('\n') if l.strip()]
base = Image.open('vista_previa_playa.png').convert('RGBA')
cargar = lambda n: Image.open(f'assets/arte/tiles/{n}.png').convert('RGBA')
tipo = {'~': 'agua', 'a': 'agua_honda', 'e': 'agua_orilla'}
cuadros = []
for t in range(8):                      # 8 pasos de 0.4 s = 2.5 fps, dos vueltas completas de 4 cuadros
    im = base.copy()
    for y, f in enumerate(filas[:22]):
        for x, ch in enumerate(f):
            # solo repinta los cuadros de agua que NO estan tapados por muelle/objetos (vienen de la vista previa)
            if ch in tipo:
                n = (t + x // 3 + y // 2) % 4 + 1
                im.paste(cargar(f"{tipo[ch]}_{n}"), (x * T, y * T))
    cuadros.append(im.crop((384, 0, 1056, 400)).convert('P'))
cuadros[0].save('vista_agua.gif', save_all=True, append_images=cuadros[1:], duration=400, loop=0)
print('listo vista_agua.gif')
