#!/usr/bin/env python3
"""Dibuja vista_previa_pueblo.png y vista_previa_playa.png con el arte que haya en assets/arte/.
NO modifica ningun PNG de arte (se puede correr aunque uses tus propios dibujos).
Uso (desde la carpeta app/):  python3 tools/vista_previa.py
"""
import json
from PIL import Image

T = 16
OUT = 'assets/arte'
SUELO_CH = '.~aes=pm'
SUELO = dict(zip('.~aes=pm', ['pasto', 'agua', 'agua_honda', 'agua_orilla', 'arena', 'camino', 'plaza', 'madera']))
SUELO['='] = 'camino'; SUELO['p'] = 'plaza'; SUELO['m'] = 'madera'
OBJ = dict(T='arbol', L='farola', F='fuente', b='banca', C='cabina', f='flores', r='roca', v='valla',
           S='sombrilla_roja', Z='sombrilla_azul', H='reposera', K='barril', B='barco', o='toalla_rayas', q='toalla_azul', h='conchas')
PLANOS = 'oqh'          # objetos planos (toallas, conchas): van pegados al suelo
GRANDES = 'FB'          # objetos de varios cuadros: se dibujan desde su esquina de arriba a la izquierda


def cargar(nombre):
    return Image.open(f'{OUT}/tiles/{nombre}.png').convert('RGBA')


def suelos(filas):
    """Igual que Mapa._calcularSuelos del juego: los objetos toman el suelo de sus vecinos."""
    h, w = len(filas), len(filas[0])
    g = [list(f.ljust(w, '~')) for f in filas]
    ok = [[g[y][x] in SUELO_CH for x in range(w)] for y in range(h)]
    for _ in range(8):
        cambios = []
        for y in range(h):
            for x in range(w):
                if ok[y][x]:
                    continue
                for dx, dy in ((0, 1), (1, 0), (-1, 0), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < w and 0 <= ny < h and ok[ny][nx]:
                        cambios.append((x, y, g[ny][nx]))
                        break
        if not cambios:
            break
        for x, y, ch in cambios:
            g[y][x] = ch
            ok[y][x] = True
    return [[g[y][x] if ok[y][x] else '.' for x in range(w)] for y in range(h)]


def dibujar(txt, datos, salida, aldo=None):
    filas = [l.rstrip('\n') for l in open(f'assets/mapa/{txt}', encoding='utf-8').read().split('\n') if l.strip()]
    s = suelos(filas)
    tiles = {n: cargar(n) for n in set(SUELO.values()) | set(OBJ.values())}
    mapa = Image.new('RGBA', (len(filas[0]) * T, len(filas) * T))
    for y, fila in enumerate(filas):
        for x in range(len(fila)):
            mapa.paste(tiles[SUELO.get(s[y][x], 'pasto')], (x * T, y * T))
    for y, fila in enumerate(filas):
        for x, ch in enumerate(fila):
            if ch not in OBJ:
                continue
            if ch in GRANDES and ((x > 0 and fila[x - 1] == ch) or (y > 0 and filas[y - 1][x] == ch)):
                continue
            o = tiles[OBJ[ch]]
            if ch in GRANDES or ch in PLANOS:
                mapa.alpha_composite(o, (x * T, y * T))
            else:
                mapa.alpha_composite(o, (x * T, y * T + T - o.height))
    for e in datos.get('edificios', []):
        mapa.alpha_composite(Image.open(f"{OUT}/edificios/{e['id']}.png").convert('RGBA'), (e['x'] * T, e['y'] * T))
    if aldo is not None:
        ix, iy = datos['inicio']
        mapa.alpha_composite(aldo, (ix * T, iy * T + T // 2 + 4 - 24 + 8))
    mapa.convert('RGB').save(salida)
    print('listo', salida, mapa.size)


hoja = Image.open(f'{OUT}/personajes/aldo.png').convert('RGBA')
frente = hoja.crop((0, 0, 16, 24))
dibujar('pueblo.txt', json.load(open('assets/mapa/edificios.json', encoding='utf-8')), 'vista_previa_pueblo.png', frente)
dibujar('playa.txt', json.load(open('assets/mapa/playa.json', encoding='utf-8')), 'vista_previa_playa.png')
